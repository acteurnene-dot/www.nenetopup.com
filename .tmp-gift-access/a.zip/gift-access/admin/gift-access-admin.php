<?php
defined('ABSPATH') || exit;

if (!defined('GIFTACCESS_ADMIN_SLUG')) {
    define('GIFTACCESS_ADMIN_SLUG', 'giftaccess');
}

add_action('admin_menu', function(){
    add_menu_page(
        'Gift Access',
        'Gift Access',
        'manage_options',
        GIFTACCESS_ADMIN_SLUG,
        'giftaccess_admin_page',
        'dashicons-vault',
        56
    );

    add_submenu_page(
        'woocommerce',
        'Gift Access',
        'Gift Access',
        'manage_options',
        GIFTACCESS_ADMIN_SLUG,
        'giftaccess_admin_page'
    );

});

add_action('admin_post_giftaccess_export_stock', 'giftaccess_export_stock_csv');
add_action('admin_post_giftaccess_export_history', 'giftaccess_export_history_csv');

function giftaccess_admin_page(){
    $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'stock';
    $page_url = admin_url('admin.php?page=' . GIFTACCESS_ADMIN_SLUG);
    $woocommerce_ready = class_exists('WooCommerce') || function_exists('WC') || function_exists('wc_get_products');

    if (!$woocommerce_ready && in_array($tab, ['stock', 'mapping', 'history'], true)) {
        $tab = 'api';
    }

    echo '<div class="wrap"><h1>Gift Access</h1>';

    if (!$woocommerce_ready) {
        echo '<div class="notice notice-error"><p><strong>WooCommerce est requis.</strong> Active WooCommerce pour gérer le stock, les produits et les livraisons.</p></div>';
    }

    echo '<h2 class="nav-tab-wrapper" style="margin-top:15px;">';
    if ($woocommerce_ready) {
        echo '<a class="nav-tab '.($tab==='stock'?'nav-tab-active':'').'" href="'.esc_url($page_url.'&tab=stock').'">Stock</a>';
        echo '<a class="nav-tab '.($tab==='mapping'?'nav-tab-active':'').'" href="'.esc_url($page_url.'&tab=mapping').'">Mapping API</a>';
    }
    echo '<a class="nav-tab '.($tab==='api'?'nav-tab-active':'').'" href="'.esc_url($page_url.'&tab=api').'">API</a>';
    echo '<a class="nav-tab '.($tab==='settings'?'nav-tab-active':'').'" href="'.esc_url($page_url.'&tab=settings').'">Paramètres</a>';
    echo '<a class="nav-tab '.($tab==='logs'?'nav-tab-active':'').'" href="'.esc_url($page_url.'&tab=logs').'">Logs API</a>';
    if ($woocommerce_ready) {
        echo '<a class="nav-tab '.($tab==='history'?'nav-tab-active':'').'" href="'.esc_url($page_url.'&tab=history').'">Historique</a>';
    }
    echo '</h2>';

    if ($tab==='history' && $woocommerce_ready) giftaccess_admin_history();
    elseif ($tab==='mapping' && $woocommerce_ready) giftaccess_admin_mapping();
    elseif ($tab==='api') giftaccess_admin_api_settings();
    elseif ($tab==='settings') giftaccess_admin_settings();
    elseif ($tab==='logs') giftaccess_admin_api_logs();
    elseif ($woocommerce_ready) giftaccess_admin_stock();
    else echo '<p>Active WooCommerce pour accéder au stock et au mapping produit.</p>';

    echo '</div>';
}

function giftaccess_admin_per_page(){
    return 20;
}

function giftaccess_admin_current_page(){
    return max(1, absint($_GET['paged'] ?? 1));
}

function giftaccess_admin_render_pagination($total_items, $current_page, $base_args){
    $per_page = giftaccess_admin_per_page();
    $total_pages = (int) ceil(max(0, (int) $total_items) / $per_page);
    if ($total_pages <= 1) {
        return;
    }

    $placeholder = 999999999;
    $base_args = array_merge($base_args, ['paged' => $placeholder]);
    $base_url = str_replace((string) $placeholder, '%#%', esc_url_raw(add_query_arg($base_args, admin_url('admin.php'))));
    $links = paginate_links([
        'base'      => $base_url,
        'format'    => '',
        'current'   => max(1, (int) $current_page),
        'total'     => $total_pages,
        'prev_text' => '&lsaquo;',
        'next_text' => '&rsaquo;',
        'type'      => 'plain',
    ]);

    if (!$links) {
        return;
    }

    echo '<div class="tablenav" style="margin:12px 0;">';
    echo '<div class="tablenav-pages" style="float:none;">';
    echo '<span class="displaying-num">'.esc_html(sprintf('%d éléments', (int) $total_items)).'</span> ';
    echo wp_kses_post($links);
    echo '</div>';
    echo '</div>';
}

function giftaccess_admin_stock(){
    global $wpdb;
    $pid = isset($_GET['pid']) ? absint($_GET['pid']) : 0;
    $vid = isset($_GET['vid']) ? absint($_GET['vid']) : 0;

    $products = wc_get_products([
        'limit' => 200,
        'type' => ['simple','variable'],
        'status' => ['publish','private'],
        'orderby' => 'title',
        'order' => 'ASC',
        'return' => 'objects',
    ]);

    $current = $pid ? wc_get_product($pid) : null;
    $variations = ($current && $current->is_type('variable')) ? giftaccess_get_variations($pid) : [];

    $t = giftaccess_stock_table();

    
    if (!empty($_POST['giftaccess_action']) && check_admin_referer('giftaccess_add','giftaccess_nonce')) {
        $action = sanitize_key(wp_unslash($_POST['giftaccess_action']));
        if ($action === 'add' && $pid){
            $pin = sanitize_text_field(wp_unslash($_POST['pin'] ?? ''));
            giftaccess_insert_pin($pid, $vid ?: null, $pin);
        }
        if ($action === 'import' && $pid && !empty($_FILES['csv']['tmp_name'])){
            giftaccess_import_csv($pid, $vid ?: null, $_FILES['csv']['tmp_name']);
        }
        wp_safe_redirect(add_query_arg(['page'=>GIFTACCESS_ADMIN_SLUG,'tab'=>'stock','pid'=>$pid,'vid'=>$vid,'updated'=>1], admin_url('admin.php')));
        exit;
    }

    
    if (!empty($_GET['del']) && !empty($_GET['row'])){
        $row = absint($_GET['row']);
        $nonce = sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? ''));
        if (wp_verify_nonce($nonce, 'giftaccess_del_'.$row)){
            $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d", $row), ARRAY_A);
            if ($r && empty($r['assigned_order'])){
                giftaccess_delete_pin($row);
            }
        }
        wp_safe_redirect(add_query_arg(['page'=>GIFTACCESS_ADMIN_SLUG,'tab'=>'stock','pid'=>$pid,'vid'=>$vid,'deleted'=>1], admin_url('admin.php')));
        exit;
    }

    $per_page = giftaccess_admin_per_page();
    $current_page = giftaccess_admin_current_page();
    $offset = ($current_page - 1) * $per_page;

    if ($pid){
        if ($vid){
            $total_items = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE product_id=%d AND variation_id=%d", $pid, $vid));
            $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE product_id=%d AND variation_id=%d ORDER BY id DESC LIMIT %d OFFSET %d", $pid, $vid, $per_page, $offset), ARRAY_A);
        } else {
            $total_items = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE product_id=%d", $pid));
            $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $t WHERE product_id=%d ORDER BY id DESC LIMIT %d OFFSET %d", $pid, $per_page, $offset), ARRAY_A);
        }
    } else {
        $total_items = (int) $wpdb->get_var("SELECT COUNT(*) FROM $t");
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM $t ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset), ARRAY_A);
    }

    if (!empty($_GET['updated'])) echo '<div class="notice notice-success"><p>Stock mis à jour.</p></div>';
    if (!empty($_GET['deleted'])) echo '<div class="notice notice-success"><p>Ligne supprimée.</p></div>';

    echo '<div style="margin-top:10px; display:flex; justify-content:space-between; align-items:center;">';
    echo '<form method="get" action="'.esc_url(admin_url('admin.php')).'" style="display:flex; gap:8px; align-items:center;">';
    echo '<input type="hidden" name="page" value="'.esc_attr(GIFTACCESS_ADMIN_SLUG).'" />';
    echo '<input type="hidden" name="tab" value="stock" />';

    echo '<select name="pid"><option value="0">— Tous les produits —</option>';
    foreach($products as $p){
        printf('<option value="%d" %s>%s (ID %d)</option>',
            $p->get_id(),
            selected($pid, $p->get_id(), false),
            esc_html($p->get_name()),
            $p->get_id()
        );
    }
    echo '</select>';

    echo '<select name="vid">';
    if (!$current || !$current->is_type('variable')){
        echo '<option value="0" selected>(Sans variation)</option>';
    } else {
        echo '<option value="0" '.selected($vid,0,false).'>Toutes variations</option>';
        foreach($variations as $v){
            printf('<option value="%d" %s>%s — ID %d</option>',
                $v['id'], selected($vid,$v['id'],false), esc_html($v['label']), $v['id']
            );
        }
    }
    echo '</select>';

    echo '<button class="button">Filtrer</button>';
    echo '</form>';

    $exp = wp_nonce_url(admin_url('admin-post.php?action=giftaccess_export_stock'), 'giftaccess_export_stock', 'giftaccess_export');
    echo '<div><a class="button" href="'.esc_url($exp).'">Export CSV</a></div>';
    echo '</div>';

    if ($pid){
        $open_url = add_query_arg(['page'=>GIFTACCESS_ADMIN_SLUG,'tab'=>'stock','pid'=>$pid,'vid'=>$vid], admin_url('admin.php'));

        echo '<div style="margin-top:16px; display:grid; grid-template-columns:1fr 1fr; gap:16px;">';

        echo '<div class="card" style="padding:16px;border:1px solid #ddd;border-radius:10px;background:#fff;">';
        echo '<h3>Ajouter un PIN</h3>';
        if ($current){
            echo '<p><strong>'.esc_html($current->get_name()).'</strong></p>';
            if ($vid){
                $vobj = wc_get_product($vid);
                if ($vobj) echo '<p><small>Variation: '.esc_html(wc_get_formatted_variation($vobj,true,false,true)).'</small></p>';
            }
        }
        echo '<form method="post" action="'.esc_url($open_url).'">';
        wp_nonce_field('giftaccess_add','giftaccess_nonce');
        echo '<input type="hidden" name="giftaccess_action" value="add" />';
        echo '<p><input class="regular-text" name="pin" placeholder="PIN..." autocomplete="off" /></p>';
        echo '<p><button class="button button-primary" type="submit">Ajouter</button></p>';
        echo '</form>';
        echo '</div>';

        echo '<div class="card" style="padding:16px;border:1px solid #ddd;border-radius:10px;background:#fff;">';
        echo '<h3>Importer CSV</h3>';
        echo '<p style="color:#666">Colonne: <code>pin</code> (ou 1ère colonne)</p>';
        echo '<form method="post" action="'.esc_url($open_url).'" enctype="multipart/form-data">';
        wp_nonce_field('giftaccess_add','giftaccess_nonce');
        echo '<input type="hidden" name="giftaccess_action" value="import" />';
        echo '<p><input type="file" name="csv" accept=".csv" /></p>';
        echo '<p><button class="button" type="submit">Importer</button></p>';
        echo '</form>';
        echo '</div>';

        echo '</div>';
    } else {
        echo '<p style="margin-top:15px;color:#666;">Sélectionne un produit pour ajouter/importer des PIN.</p>';
    }

    echo '<h3 style="margin-top:24px;">Stock</h3>';
    giftaccess_admin_render_pagination($total_items, $current_page, ['page'=>GIFTACCESS_ADMIN_SLUG,'tab'=>'stock','pid'=>$pid,'vid'=>$vid]);
    echo '<table class="widefat striped"><thead><tr>';
    echo '<th>ID</th><th>Produit/Variation</th><th>PIN</th><th>Statut</th><th>Claimed</th><th>Action</th>';
    echo '</tr></thead><tbody>';

    if (empty($rows)){
        echo '<tr><td colspan="6">Aucune donnée.</td></tr>';
    } else {
        foreach($rows as $r){
            if (!empty($r['variation_id'])){
                $v = wc_get_product((int)$r['variation_id']);
                $label = $v ? wc_get_formatted_variation($v,true,false,true) : 'Variation';
            } else {
                $p = wc_get_product((int)$r['product_id']);
                $label = $p ? $p->get_name() : 'Produit';
            }
            $status = empty($r['assigned_order']) ? 'LIBRE' : 'ASSIGNÉ';
            $claimed = !empty($r['claimed_at']) ? 'Oui' : 'Non';

            $del_url = wp_nonce_url(
                add_query_arg([
                    'page'=>GIFTACCESS_ADMIN_SLUG,'tab'=>'stock','pid'=>$pid,'vid'=>$vid,
                    'del'=>1,'row'=>(int)$r['id']
                ], admin_url('admin.php')),
                'giftaccess_del_'.$r['id']
            );

            echo '<tr>';
            echo '<td>'.(int)$r['id'].'</td>';
            echo '<td>'.esc_html($label).'</td>';
            echo '<td><code>'.esc_html($r['data_pin']).'</code></td>';
            echo '<td>'.($status==='LIBRE' ? '<span style="color:green">LIBRE</span>' : '<span style="color:#777">ASSIGNÉ</span>').'</td>';
            echo '<td>'.$claimed.'</td>';
            echo '<td>';
            if ($status==='LIBRE'){
                echo '<a class="button button-small" href="'.esc_url($del_url).'" onclick="return confirm(\'Supprimer ce PIN ?\');">Supprimer</a>';
            } else {
                echo '—';
            }
            echo '</td>';
            echo '</tr>';
        }
    }
    echo '</tbody></table>';
    giftaccess_admin_render_pagination($total_items, $current_page, ['page'=>GIFTACCESS_ADMIN_SLUG,'tab'=>'stock','pid'=>$pid,'vid'=>$vid]);
}

function giftaccess_admin_history(){
    global $wpdb;
    $t = giftaccess_history_table();
    $rows = [];
    $local_rows = $wpdb->get_results("SELECT * FROM $t ORDER BY id DESC LIMIT 300", ARRAY_A);

    foreach ($local_rows as $r) {
        if (!empty($r['variation_id'])){
            $v = wc_get_product((int)$r['variation_id']);
            $label = $v ? wc_get_formatted_variation($v,true,false,true) : 'Variation';
        } else {
            $p = wc_get_product((int)$r['product_id']);
            $label = $p ? $p->get_name() : 'Produit';
        }

        $rows[] = [
            'sort' => strtotime((string) $r['created_at']) ?: 0,
            'source' => 'Stock local',
            'id' => 'S' . (int) $r['id'],
            'label' => $label,
            'order_id' => (int) $r['order_id'],
            'code' => (string) $r['data_pin'],
            'date' => (string) $r['created_at'],
        ];
    }

    if (function_exists('wc_get_orders')) {
        $statuses = function_exists('wc_get_order_statuses') ? array_keys(wc_get_order_statuses()) : [];
        $statuses = array_map(function($status){
            return preg_replace('/^wc-/', '', (string) $status);
        }, $statuses);
        if (empty($statuses)) {
            $statuses = ['pending','processing','completed','on-hold','failed','cancelled','refunded'];
        }

        $orders = wc_get_orders([
            'limit' => 300,
            'status' => $statuses,
            'orderby' => 'date',
            'order' => 'DESC',
            'return' => 'objects',
        ]);

        $api_history_lookups = 0;

        foreach ($orders as $order) {
            if (!is_a($order, 'WC_Order')) {
                continue;
            }

            foreach ($order->get_items('line_item') as $item_id => $item) {
                $api_status = (string) $item->get_meta('_giftaccess_api_status', true);
                if ($api_status === '') {
                    continue;
                }

                $deliveries = $item->get_meta('_giftaccess_api_deliveries', true);
                if (!is_array($deliveries)) {
                    $deliveries = [];
                }

                if (empty($deliveries) && function_exists('giftaccess_api_normalized_deliveries')) {
                    $response = $item->get_meta('_giftaccess_api_response', true);
                    $deliveries = giftaccess_api_normalized_deliveries($response);
                }

                $api_reference = (string) $item->get_meta('_giftaccess_api_reference', true);
                if (
                    empty($deliveries)
                    && $api_status === 'success'
                    && $api_reference !== ''
                    && $api_history_lookups < 20
                    && function_exists('giftaccess_api_request')
                    && function_exists('giftaccess_api_normalized_deliveries')
                ) {
                    $api_history_lookups++;
                    $details = giftaccess_api_request('GET', '/orders/' . rawurlencode($api_reference));
                    if (!is_wp_error($details)) {
                        $deliveries = giftaccess_api_normalized_deliveries($details);
                        if (!empty($deliveries)) {
                            $item->update_meta_data('_giftaccess_api_deliveries', $deliveries);
                            $item->save();
                        }
                    }
                }

                $date = (string) $item->get_meta('_giftaccess_api_date', true);
                if ($date === '' && $order->get_date_created()) {
                    $date = $order->get_date_created()->date('Y-m-d H:i:s');
                }

                if (!empty($deliveries)) {
                    foreach ($deliveries as $delivery_index => $delivery) {
                        if (!is_array($delivery) || empty($delivery['value'])) {
                            continue;
                        }

                        $rows[] = [
                            'sort' => strtotime($date) ?: 0,
                            'source' => 'API',
                            'id' => 'A' . (int)$order->get_id() . '-' . (int)$item_id . '-' . (int)$delivery_index,
                            'label' => $item->get_name(),
                            'order_id' => (int) $order->get_id(),
                            'code' => (string) $delivery['value'],
                            'date' => $date,
                        ];
                    }
                } else {
                    $rows[] = [
                        'sort' => strtotime($date) ?: 0,
                        'source' => 'API',
                        'id' => 'A' . (int)$order->get_id() . '-' . (int)$item_id,
                        'label' => $item->get_name(),
                        'order_id' => (int) $order->get_id(),
                        'code' => $api_status === 'success' ? 'Code non enregistré' : strtoupper($api_status),
                        'date' => $date,
                    ];
                }
            }
        }
    }

    usort($rows, function($a, $b){
        return ($b['sort'] <=> $a['sort']);
    });
    $rows = array_slice($rows, 0, 300);
    $total_items = count($rows);
    $current_page = giftaccess_admin_current_page();
    $per_page = giftaccess_admin_per_page();
    $rows = array_slice($rows, ($current_page - 1) * $per_page, $per_page);

    $exp = wp_nonce_url(admin_url('admin-post.php?action=giftaccess_export_history'), 'giftaccess_export_history', 'giftaccess_export');

    echo '<div style="margin-top:12px; display:flex; justify-content:space-between; align-items:center;">';
    echo '<a class="button" href="'.esc_url($exp).'">Export CSV stock local</a>';
    echo '</div>';

    giftaccess_admin_render_pagination($total_items, $current_page, ['page'=>GIFTACCESS_ADMIN_SLUG,'tab'=>'history']);
    echo '<table class="widefat striped" style="margin-top:10px;"><thead><tr>';
    echo '<th>ID</th><th>Mode</th><th>Produit/Variation</th><th>Commande</th><th>Code livré</th><th>Date</th>';
    echo '</tr></thead><tbody>';

    if (empty($rows)){
        echo '<tr><td colspan="6">Aucune livraison.</td></tr>';
    } else {
        foreach($rows as $r){
            $order_link = '';
            if (!empty($r['order_id'])) {
                $order = wc_get_order((int)$r['order_id']);
                if ($order) {
                    $order_link = '<a href="'.esc_url($order->get_edit_order_url()).'">#'.(int)$r['order_id'].'</a>';
                } else {
                    $order_link = '#'.(int)$r['order_id'];
                }
            }

            $source_color = $r['source'] === 'API' ? '#2271b1' : '#008a20';

            echo '<tr>';
            echo '<td>'.esc_html($r['id']).'</td>';
            echo '<td><span style="display:inline-block;padding:2px 8px;border-radius:999px;background:'.esc_attr($source_color).';color:#fff;font-size:11px;font-weight:700;">'.esc_html($r['source']).'</span></td>';
            echo '<td>'.esc_html($r['label']).'</td>';
            echo '<td>'.$order_link.'</td>';
            echo '<td><code style="white-space:pre-wrap;">'.esc_html($r['code']).'</code></td>';
            echo '<td>'.esc_html($r['date']).'</td>';
            echo '</tr>';
        }
    }

    echo '</tbody></table>';
    giftaccess_admin_render_pagination($total_items, $current_page, ['page'=>GIFTACCESS_ADMIN_SLUG,'tab'=>'history']);
}

function giftaccess_admin_product_choices(){
    return wc_get_products([
        'limit' => 300,
        'type' => ['simple','variable'],
        'status' => ['publish','private'],
        'orderby' => 'title',
        'order' => 'ASC',
        'return' => 'objects',
    ]);
}

function giftaccess_admin_mapping(){
    $pid = isset($_GET['pid']) ? absint($_GET['pid']) : 0;
    $vid = isset($_GET['vid']) ? absint($_GET['vid']) : 0;
    $target_notice = '';
    $target_error = '';

    if (!empty($_GET['target_id'])) {
        $resolved = giftaccess_admin_resolve_mapping_target(absint($_GET['target_id']));
        if (!empty($resolved['error'])) {
            $target_error = $resolved['error'];
        } else {
            $pid = (int) $resolved['pid'];
            $vid = (int) $resolved['vid'];
            $target_notice = $resolved['notice'];
        }
    }

    if (!empty($_POST['giftaccess_action']) && check_admin_referer('giftaccess_mapping','giftaccess_nonce')) {
        $pid = absint($_POST['pid'] ?? 0);
        $vid = absint($_POST['vid'] ?? 0);
        $target_id = $vid ?: $pid;

        if ($target_id) {
            $delivery_mode = sanitize_key(wp_unslash($_POST['_giftaccess_delivery_mode'] ?? 'stock'));
            if (!in_array($delivery_mode, ['stock','api','hybrid'], true)) {
                $delivery_mode = 'stock';
            }

            $enabled = sanitize_key(wp_unslash($_POST['_giftaccess_api_enabled'] ?? 'no'));
            if (!in_array($enabled, ['inherit','yes','no'], true)) {
                $enabled = 'no';
            }

            $service = sanitize_key(wp_unslash($_POST['_giftaccess_api_service_type'] ?? 'freefire'));
            if (!in_array($service, ['freefire','giftcard','airtime','topup'], true)) {
                $service = 'freefire';
            }

            update_post_meta($target_id, '_giftaccess_delivery_mode', $delivery_mode);
            update_post_meta($target_id, '_giftaccess_api_enabled', $enabled);
            update_post_meta($target_id, '_giftaccess_api_service_type', $service);
            update_post_meta($target_id, '_giftaccess_api_product_id', sanitize_text_field(wp_unslash($_POST['_giftaccess_api_product_id'] ?? '')));
            update_post_meta($target_id, '_giftaccess_api_fixed_amount', wc_format_decimal(wp_unslash($_POST['_giftaccess_api_fixed_amount'] ?? '')));
            update_post_meta($target_id, '_giftaccess_api_currency', strtoupper(sanitize_text_field(wp_unslash($_POST['_giftaccess_api_currency'] ?? 'USD'))));
            update_post_meta($target_id, '_giftaccess_api_country', strtoupper(sanitize_text_field(wp_unslash($_POST['_giftaccess_api_country'] ?? ''))));
            update_post_meta($target_id, '_giftaccess_api_operator_brand', sanitize_text_field(wp_unslash($_POST['_giftaccess_api_operator_brand'] ?? '')));

            echo '<div class="notice notice-success"><p>Mapping API enregistré.</p></div>';
        }
    }

    $products = giftaccess_admin_product_choices();
    $current = $pid ? wc_get_product($pid) : null;
    $variations = ($current && $current->is_type('variable')) ? giftaccess_get_variations($pid) : [];
    $target_id = $vid ?: $pid;

    echo '<h2>Mapping hybride FreeFire/API</h2>';

    if ($target_notice) {
        echo '<div class="notice notice-info"><p>'.esc_html($target_notice).'</p></div>';
    }

    if ($target_error) {
        echo '<div class="notice notice-error"><p>'.esc_html($target_error).'</p></div>';
    }

    echo '<form method="get" action="'.esc_url(admin_url('admin.php')).'" style="display:flex; gap:8px; align-items:center; margin:15px 0;">';
    echo '<input type="hidden" name="page" value="'.esc_attr(GIFTACCESS_ADMIN_SLUG).'" />';
    echo '<input type="hidden" name="tab" value="mapping" />';
    echo '<select name="pid"><option value="0">Choisir un produit WooCommerce</option>';
    foreach($products as $p){
        printf('<option value="%d" %s>%s (ID %d)</option>',
            $p->get_id(),
            selected($pid, $p->get_id(), false),
            esc_html($p->get_name()),
            $p->get_id()
        );
    }
    echo '</select>';

    echo '<select name="vid">';
    if (!$current || !$current->is_type('variable')){
        echo '<option value="0" selected>Produit simple / parent</option>';
    } else {
        echo '<option value="0" '.selected($vid,0,false).'>Produit parent</option>';
        foreach($variations as $v){
            printf('<option value="%d" %s>%s - ID %d</option>',
                $v['id'], selected($vid,$v['id'],false), esc_html($v['label']), $v['id']
            );
        }
    }
    echo '</select>';
    echo '<button class="button">Ouvrir</button>';
    echo '</form>';

    if (!$target_id) {
        echo '<p>Sélectionne un produit pour configurer l’API.</p>';
        return;
    }

    $direct = function($key, $default = '') use ($target_id) {
        $value = get_post_meta($target_id, $key, true);
        return $value === '' ? $default : $value;
    };

    $delivery_mode = $direct('_giftaccess_delivery_mode', 'stock');
    $enabled = $direct('_giftaccess_api_enabled', $vid ? 'inherit' : 'no');
    $service = $direct('_giftaccess_api_service_type', 'freefire');

    echo '<form method="post" action="'.esc_url(add_query_arg(['page'=>GIFTACCESS_ADMIN_SLUG,'tab'=>'mapping','pid'=>$pid,'vid'=>$vid], admin_url('admin.php'))).'" class="card" style="max-width:980px;padding:18px;">';
    wp_nonce_field('giftaccess_mapping','giftaccess_nonce');
    echo '<input type="hidden" name="giftaccess_action" value="save_mapping" />';
    echo '<input type="hidden" name="pid" value="'.(int)$pid.'" />';
    echo '<input type="hidden" name="vid" value="'.(int)$vid.'" />';

    echo '<table class="form-table" role="presentation"><tbody>';
    echo '<tr><th scope="row">Cible WooCommerce</th><td><strong>ID '.(int)$target_id.'</strong>'.($vid ? ' (variation)' : ' (produit)').'</td></tr>';
    echo '<tr><th scope="row"><label>Mode livraison</label></th><td><select id="giftaccess_delivery_mode" name="_giftaccess_delivery_mode">';
    foreach(['stock'=>'Stock PIN seulement','api'=>'API seulement','hybrid'=>'Hybride stock + API'] as $value => $label){
        echo '<option value="'.esc_attr($value).'" '.selected($delivery_mode,$value,false).'>'.esc_html($label).'</option>';
    }
    echo '</select></td></tr>';

    echo '<tr><th scope="row"><label>Activer API</label></th><td><select id="giftaccess_api_enabled" name="_giftaccess_api_enabled">';
    $enabled_options = $vid ? ['inherit'=>'Hériter du parent','yes'=>'Oui','no'=>'Non'] : ['yes'=>'Oui','no'=>'Non'];
    foreach($enabled_options as $value => $label){
        echo '<option value="'.esc_attr($value).'" '.selected($enabled,$value,false).'>'.esc_html($label).'</option>';
    }
    echo '</select></td></tr>';

    echo '<tr class="giftaccess-mapping-api-row"><th scope="row"><label>Type API</label></th><td><select name="_giftaccess_api_service_type">';
    foreach(['freefire'=>'FreeFire / Top-up','topup'=>'Top-up générique','giftcard'=>'Gift card','airtime'=>'Airtime'] as $value => $label){
        echo '<option value="'.esc_attr($value).'" '.selected($service,$value,false).'>'.esc_html($label).'</option>';
    }
    echo '</select></td></tr>';

    giftaccess_admin_text_row('ID produit API', '_giftaccess_api_product_id', $direct('_giftaccess_api_product_id'), 'Exemple : ID produit FreeFire/Gift Access.', 'giftaccess-mapping-api-row');
    giftaccess_admin_text_row('Devise API', '_giftaccess_api_currency', $direct('_giftaccess_api_currency', 'USD'), 'Exemple : USD.', 'giftaccess-mapping-api-row');

    echo '</tbody></table>';
    echo '<p><button class="button button-primary" type="submit">Enregistrer mapping</button></p>';
    echo '</form>';
    echo '<script>
(function(){
    var mode = document.getElementById("giftaccess_delivery_mode");
    var enabled = document.getElementById("giftaccess_api_enabled");
    var rows = document.querySelectorAll(".giftaccess-mapping-api-row");
    function syncMappingRows(){
        var show = mode && mode.value !== "stock" && (!enabled || enabled.value !== "no");
        rows.forEach(function(row){ row.style.display = show ? "" : "none"; });
    }
    if (mode) mode.addEventListener("change", syncMappingRows);
    if (enabled) enabled.addEventListener("change", syncMappingRows);
    syncMappingRows();
})();
</script>';
}

function giftaccess_admin_resolve_mapping_target($target_id){
    $product = wc_get_product($target_id);
    if (!$product) {
        return [
            'error' => sprintf('Aucun produit ou variation WooCommerce trouvé pour l’ID %d.', $target_id),
        ];
    }

    if ($product->is_type('variation')) {
        return [
            'pid'    => (int) $product->get_parent_id(),
            'vid'    => (int) $product->get_id(),
            'notice' => sprintf('Variation WooCommerce détectée : ID %d. Mapping ouvert sur cette variation.', $target_id),
        ];
    }

    if ($product->is_type('variable')) {
        $children = $product->get_children();
        if (!empty($children)) {
            $first_variation_id = (int) reset($children);
            return [
                'pid'    => (int) $product->get_id(),
                'vid'    => $first_variation_id,
                'notice' => sprintf('Produit variable détecté : ID %d. La première variation disponible (%d) est ouverte pour éviter une configuration sur le parent.', $target_id, $first_variation_id),
            ];
        }
    }

    return [
        'pid'    => (int) $product->get_id(),
        'vid'    => 0,
        'notice' => sprintf('Produit WooCommerce détecté : ID %d.', $target_id),
    ];
}

function giftaccess_admin_text_row($label, $name, $value, $desc = '', $row_class = ''){
    $class_attr = $row_class !== '' ? ' class="'.esc_attr($row_class).'"' : '';
    echo '<tr'.$class_attr.'><th scope="row"><label for="'.esc_attr($name).'">'.esc_html($label).'</label></th><td>';
    echo '<input class="regular-text" id="'.esc_attr($name).'" name="'.esc_attr($name).'" value="'.esc_attr($value).'" />';
    if ($desc) {
        echo '<p class="description">'.esc_html($desc).'</p>';
    }
    echo '</td></tr>';
}

function giftaccess_admin_settings(){
    if (!empty($_POST['giftaccess_action']) && check_admin_referer('giftaccess_settings','giftaccess_nonce')) {
        $block_color = giftaccess_sanitize_hex_setting(wp_unslash($_POST['giftaccess_delivery_block_color'] ?? ''), '#ffffff');
        $button_color = giftaccess_sanitize_hex_setting(wp_unslash($_POST['giftaccess_delivery_button_color'] ?? ''), '#d39a3c');
        $redeem_url = esc_url_raw(trim((string) wp_unslash($_POST['giftaccess_redeem_url'] ?? '')));

        update_option('giftaccess_delivery_block_color', $block_color, false);
        update_option('giftaccess_delivery_button_color', $button_color, false);
        update_option('giftaccess_redeem_url', $redeem_url, false);

        echo '<div class="notice notice-success"><p>Paramètres enregistrés.</p></div>';
    }

    $block_color = giftaccess_delivery_block_color();
    $button_color = giftaccess_delivery_button_color();
    $redeem_url = giftaccess_redeem_url();
    $redeem_shortcode = '[giftaccess_redeem]';

    echo '<h2>Paramètres d’affichage</h2>';
    echo '<form method="post" class="card" style="max-width:860px;padding:18px;">';
    wp_nonce_field('giftaccess_settings','giftaccess_nonce');
    echo '<input type="hidden" name="giftaccess_action" value="save_settings" />';
    echo '<table class="form-table" role="presentation"><tbody>';
    echo '<tr><th scope="row"><label for="giftaccess_delivery_block_color">Couleur du bloc PIN</label></th><td>';
    echo '<input id="giftaccess_delivery_block_color" type="color" name="giftaccess_delivery_block_color" value="'.esc_attr($block_color).'" /> ';
    echo '<input class="regular-text" value="'.esc_attr($block_color).'" readonly style="width:110px;" />';
    echo '<p class="description">Fond du bloc qui affiche les codes/PIN livrés au client.</p>';
    echo '</td></tr>';
    echo '<tr><th scope="row"><label for="giftaccess_delivery_button_color">Couleur des boutons</label></th><td>';
    echo '<input id="giftaccess_delivery_button_color" type="color" name="giftaccess_delivery_button_color" value="'.esc_attr($button_color).'" /> ';
    echo '<input class="regular-text" value="'.esc_attr($button_color).'" readonly style="width:110px;" />';
    echo '<p class="description">Couleur des boutons COPIER et Réclamer.</p>';
    echo '</td></tr>';
    echo '<tr><th scope="row"><label for="giftaccess_redeem_url">Lien page Réclamer</label></th><td>';
    echo '<input id="giftaccess_redeem_url" class="regular-text" style="min-width:520px" name="giftaccess_redeem_url" value="'.esc_attr($redeem_url).'" placeholder="'.esc_attr(site_url('/'.GIFTACCESS_REDEEM_SLUG.'/')).'" />';
    echo '</td></tr>';
    echo '<tr><th scope="row"><label for="giftaccess_redeem_shortcode">Shortcode bloc Réclamer</label></th><td>';
    echo '<input id="giftaccess_redeem_shortcode" class="regular-text" style="width:220px" value="'.esc_attr($redeem_shortcode).'" readonly onclick="this.select();" /> ';
    echo '<button type="button" class="button" data-giftaccess-copy-shortcode>Copier</button>';
    echo '</td></tr>';
    echo '</tbody></table>';
    echo '<div style="margin:12px 0;padding:12px;border:1px solid #ddd;border-radius:12px;background:'.esc_attr($block_color).';max-width:560px;">';
    echo '<strong>Aperçu livraison PIN</strong><br><code>CODE-EXEMPLE-123</code> ';
    echo '<span style="display:inline-block;margin-left:10px;padding:8px 12px;border-radius:10px;background:'.esc_attr($button_color).';color:#fff;font-weight:700;">COPIER</span>';
    echo '</div>';
    echo '<p><button class="button button-primary" type="submit">Enregistrer</button></p>';
    echo '</form>';
    echo '<script>
(function(){
    var button = document.querySelector("[data-giftaccess-copy-shortcode]");
    var input = document.getElementById("giftaccess_redeem_shortcode");
    if (!button || !input) return;
    button.addEventListener("click", function(){
        input.select();
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(input.value);
        } else {
            document.execCommand("copy");
        }
        button.textContent = "Copié";
        setTimeout(function(){ button.textContent = "Copier"; }, 1200);
    });
})();
</script>';
}

function giftaccess_admin_api_settings(){
    if (!function_exists('giftaccess_api_test_connection')) {
        echo '<div class="notice notice-error"><p>Module API indisponible.</p></div>';
        return;
    }

    if (!empty($_POST['giftaccess_action']) && check_admin_referer('giftaccess_api_settings','giftaccess_nonce')) {
        $enabled = !empty($_POST['giftaccess_api_enabled']) ? 'yes' : 'no';
        $production_base_url = esc_url_raw(wp_unslash($_POST['giftaccess_api_production_base_url'] ?? ''));
        $production_key = sanitize_text_field(wp_unslash($_POST['giftaccess_api_production_key'] ?? ''));
        $production_secret = sanitize_text_field(wp_unslash($_POST['giftaccess_api_production_secret'] ?? ''));
        update_option('giftaccess_api_enabled', $enabled, false);
        update_option('giftaccess_api_mode', sanitize_key(wp_unslash($_POST['giftaccess_api_mode'] ?? 'production')), false);
        update_option('giftaccess_api_sandbox_base_url', esc_url_raw(wp_unslash($_POST['giftaccess_api_sandbox_base_url'] ?? '')), false);
        update_option('giftaccess_api_sandbox_key', sanitize_text_field(wp_unslash($_POST['giftaccess_api_sandbox_key'] ?? '')), false);
        update_option('giftaccess_api_sandbox_secret', sanitize_text_field(wp_unslash($_POST['giftaccess_api_sandbox_secret'] ?? '')), false);
        update_option('giftaccess_api_production_base_url', $production_base_url, false);
        update_option('giftaccess_api_production_key', $production_key, false);
        update_option('giftaccess_api_production_secret', $production_secret, false);
        update_option('giftaccess_api_base_url', $production_base_url, false);
        update_option('giftaccess_api_key', $production_key, false);
        update_option('giftaccess_api_secret', $production_secret, false);
        update_option('giftaccess_api_timeout', max(5, min(120, absint($_POST['giftaccess_api_timeout'] ?? 30))), false);

        echo '<div class="notice notice-success"><p>Réglages API enregistrés.</p></div>';

        if (!empty($_POST['test_api'])) {
            $test = giftaccess_api_test_connection();
            if (is_wp_error($test)) {
                echo '<div class="notice notice-error"><p>Test API échoué : '.esc_html($test->get_error_message()).'</p></div>';
            } else {
                echo '<div class="notice notice-success"><p>Connexion API OK.</p></div>';
            }
        }
    }

    echo '<h2>Réglages API Gift Access</h2>';
    echo '<form method="post" class="card" style="max-width:980px;padding:18px;">';
    wp_nonce_field('giftaccess_api_settings','giftaccess_nonce');
    echo '<input type="hidden" name="giftaccess_action" value="save_api" />';
    echo '<table class="form-table" role="presentation"><tbody>';
    echo '<tr><th scope="row">Activer livraison API</th><td><label><input type="checkbox" name="giftaccess_api_enabled" value="yes" '.checked(giftaccess_api_option('enabled','no'),'yes',false).' /> Oui</label></td></tr>';
    echo '<tr><th scope="row">Mode</th><td><select id="giftaccess_api_mode" name="giftaccess_api_mode">';
    foreach(['production'=>'Production','sandbox'=>'Sandbox'] as $value => $label){
        echo '<option value="'.esc_attr($value).'" '.selected(giftaccess_api_option('mode','production'),$value,false).'>'.esc_html($label).'</option>';
    }
    echo '</select></td></tr>';
    echo '<tr class="giftaccess-api-env-row" data-api-env="sandbox"><th colspan="2"><h3>Sandbox</h3></th></tr>';
    echo '<tr class="giftaccess-api-env-row" data-api-env="sandbox"><th scope="row"><label>URL API sandbox</label></th><td><input class="regular-text" style="min-width:520px" name="giftaccess_api_sandbox_base_url" value="'.esc_attr(giftaccess_api_base_url('sandbox')).'" /><p class="description">Souvent : https://portal.gift-access.com/api/v1</p></td></tr>';
    echo '<tr class="giftaccess-api-env-row" data-api-env="sandbox"><th scope="row"><label>Clé API sandbox</label></th><td><input class="regular-text" name="giftaccess_api_sandbox_key" value="'.esc_attr(giftaccess_api_key('sandbox')).'" autocomplete="off" placeholder="ga_sbox_..." /></td></tr>';
    echo '<tr class="giftaccess-api-env-row" data-api-env="sandbox"><th scope="row"><label>Secret sandbox</label></th><td><input class="regular-text" type="password" name="giftaccess_api_sandbox_secret" value="'.esc_attr(giftaccess_api_secret('sandbox')).'" autocomplete="off" /></td></tr>';
    echo '<tr class="giftaccess-api-env-row" data-api-env="production"><th colspan="2"><h3>Production</h3></th></tr>';
    echo '<tr class="giftaccess-api-env-row" data-api-env="production"><th scope="row"><label>URL API production</label></th><td><input class="regular-text" style="min-width:520px" name="giftaccess_api_production_base_url" value="'.esc_attr(giftaccess_api_base_url('production')).'" /><p class="description">Souvent : https://portal.gift-access.com/api/v1</p></td></tr>';
    echo '<tr class="giftaccess-api-env-row" data-api-env="production"><th scope="row"><label>Clé API production</label></th><td><input class="regular-text" name="giftaccess_api_production_key" value="'.esc_attr(giftaccess_api_key('production')).'" autocomplete="off" placeholder="ga_live_..." /></td></tr>';
    echo '<tr class="giftaccess-api-env-row" data-api-env="production"><th scope="row"><label>Secret production</label></th><td><input class="regular-text" type="password" name="giftaccess_api_production_secret" value="'.esc_attr(giftaccess_api_secret('production')).'" autocomplete="off" /></td></tr>';
    echo '<tr><th scope="row"><label>Timeout</label></th><td><input type="number" min="5" max="120" step="1" name="giftaccess_api_timeout" value="'.esc_attr(giftaccess_api_timeout()).'" /> secondes</td></tr>';
    echo '</tbody></table>';
    echo '<p><button class="button button-primary" type="submit">Enregistrer</button> <button class="button" type="submit" name="test_api" value="1">Enregistrer et tester</button></p>';
    echo '</form>';
    echo '<script>
(function(){
    var mode = document.getElementById("giftaccess_api_mode");
    var rows = document.querySelectorAll(".giftaccess-api-env-row");
    function syncApiRows(){
        var value = mode ? mode.value : "production";
        rows.forEach(function(row){
            row.style.display = row.getAttribute("data-api-env") === value ? "" : "none";
        });
    }
    if (mode) mode.addEventListener("change", syncApiRows);
    syncApiRows();
})();
</script>';
}

function giftaccess_admin_api_logs(){
    if (!function_exists('giftaccess_api_get_logs')) {
        echo '<div class="notice notice-error"><p>Module API indisponible.</p></div>';
        return;
    }

    if (!empty($_POST['giftaccess_action']) && check_admin_referer('giftaccess_api_logs','giftaccess_nonce')) {
        giftaccess_api_clear_logs();
        echo '<div class="notice notice-success"><p>Logs API vidés.</p></div>';
    }

    if (isset($_GET['log']) && function_exists('giftaccess_api_get_log')) {
        giftaccess_admin_api_log_detail(absint($_GET['log']));
        return;
    }

    $logs = function_exists('giftaccess_api_get_logs_with_ids')
        ? giftaccess_api_get_logs_with_ids(200)
        : giftaccess_api_get_logs(200);
    $total_items = count($logs);
    $current_page = giftaccess_admin_current_page();
    $per_page = giftaccess_admin_per_page();
    $logs = array_slice($logs, ($current_page - 1) * $per_page, $per_page);

    echo '<h2>Logs API</h2>';
    echo '<form method="post" style="margin:10px 0;">';
    wp_nonce_field('giftaccess_api_logs','giftaccess_nonce');
    echo '<input type="hidden" name="giftaccess_action" value="clear_logs" />';
    echo '<button class="button" onclick="return confirm(\'Vider tous les logs API ?\');">Vider les logs API</button>';
    echo '</form>';

    giftaccess_admin_render_pagination($total_items, $current_page, ['page'=>GIFTACCESS_ADMIN_SLUG,'tab'=>'logs']);
    echo '<table class="widefat striped"><thead><tr><th>Date UTC</th><th>Niveau</th><th>Message</th><th>Endpoint</th><th>Statut</th><th>Commande</th><th>Action</th></tr></thead><tbody>';
    if (empty($logs)) {
        echo '<tr><td colspan="7">Aucun log API.</td></tr>';
    } else {
        foreach($logs as $log){
            $context = is_array($log['context'] ?? null) ? $log['context'] : [];
            $response = is_array($context['response'] ?? null) ? $context['response'] : [];
            $log_id = isset($log['_log_id']) ? absint($log['_log_id']) : null;
            $detail_url = $log_id !== null
                ? add_query_arg(['page'=>GIFTACCESS_ADMIN_SLUG,'tab'=>'logs','log'=>$log_id], admin_url('admin.php'))
                : '';

            echo '<tr>';
            echo '<td>'.esc_html($log['time'] ?? '').'</td>';
            echo '<td>'.esc_html(strtoupper($log['level'] ?? '')).'</td>';
            echo '<td>'.esc_html($log['message'] ?? '').'</td>';
            echo '<td><code>'.esc_html(($context['method'] ?? '').' '.($context['endpoint'] ?? '')).'</code></td>';
            echo '<td>'.esc_html($context['status'] ?? '').'</td>';
            echo '<td>'.esc_html($response['order_id'] ?? '').'</td>';
            echo '<td>';
            if ($detail_url !== '') {
                echo '<a class="button button-small" href="'.esc_url($detail_url).'">Voir logs</a>';
            } else {
                echo '&mdash;';
            }
            echo '</td>';
            echo '</tr>';
        }
    }
    echo '</tbody></table>';
    giftaccess_admin_render_pagination($total_items, $current_page, ['page'=>GIFTACCESS_ADMIN_SLUG,'tab'=>'logs']);
}

function giftaccess_admin_api_log_detail($log_id){
    $log = giftaccess_api_get_log($log_id);
    $back_url = add_query_arg(['page'=>GIFTACCESS_ADMIN_SLUG,'tab'=>'logs'], admin_url('admin.php'));

    echo '<p><a class="button" href="'.esc_url($back_url).'">&larr; Retour aux logs</a></p>';

    if (!$log) {
        echo '<div class="notice notice-error"><p>Log API introuvable.</p></div>';
        return;
    }

    $context = is_array($log['context'] ?? null) ? $log['context'] : [];
    $payload = is_array($context['payload'] ?? null) ? $context['payload'] : [];
    $response = is_array($context['response'] ?? null) ? $context['response'] : [];
    $fields = is_array($payload['fields'] ?? null) ? $payload['fields'] : [];

    echo '<h2>Détail log API</h2>';
    echo '<div class="card" style="max-width:1200px;padding:18px;margin-top:12px;">';
    echo '<h3 style="margin-top:0;">Résumé</h3>';
    echo '<table class="widefat striped"><tbody>';
    giftaccess_admin_log_row('Date UTC', $log['time'] ?? '');
    giftaccess_admin_log_row('Niveau', strtoupper((string) ($log['level'] ?? '')));
    giftaccess_admin_log_row('Message', $log['message'] ?? '');
    giftaccess_admin_log_row('Mode', $context['mode'] ?? '');
    giftaccess_admin_log_row('Endpoint', trim((string) (($context['method'] ?? '').' '.($context['endpoint'] ?? ''))));
    giftaccess_admin_log_row('Statut HTTP', $context['status'] ?? '');
    giftaccess_admin_log_row('Clé', $context['key_hint'] ?? '');
    giftaccess_admin_log_row('Commande API', $response['order_id'] ?? '');
    giftaccess_admin_log_row('Statut commande', $response['status'] ?? '');
    giftaccess_admin_log_row('Produit API', $payload['product_id'] ?? '');
    giftaccess_admin_log_row('Référence', $payload['reference'] ?? '');
    giftaccess_admin_log_row('Client', trim((string) (($fields['recipient_name'] ?? '').' '.($fields['recipient_email'] ?? ''))));
    echo '</tbody></table>';
    echo '</div>';

    echo '<div style="max-width:1200px;margin-top:16px;display:grid;grid-template-columns:1fr 1fr;gap:16px;">';
    giftaccess_admin_log_json_card('Payload envoyé', $payload);
    giftaccess_admin_log_json_card('Réponse API', $response);
    echo '</div>';

    echo '<div class="card" style="max-width:1200px;padding:18px;margin-top:16px;">';
    echo '<h3 style="margin-top:0;">Contexte complet</h3>';
    echo '<pre style="white-space:pre-wrap;overflow:auto;max-height:520px;background:#111;color:#f5f5f5;padding:14px;border-radius:4px;">'.esc_html(giftaccess_admin_json($context)).'</pre>';
    echo '</div>';
}

function giftaccess_admin_log_row($label, $value){
    if (is_array($value) || is_object($value)) {
        $value = giftaccess_admin_json($value);
    }

    echo '<tr><th style="width:220px;">'.esc_html($label).'</th><td>'.esc_html((string) $value).'</td></tr>';
}

function giftaccess_admin_log_json_card($title, $data){
    echo '<div class="card" style="padding:18px;min-width:0;">';
    echo '<h3 style="margin-top:0;">'.esc_html($title).'</h3>';
    echo '<pre style="white-space:pre-wrap;overflow:auto;max-height:520px;background:#111;color:#f5f5f5;padding:14px;border-radius:4px;">'.esc_html(giftaccess_admin_json($data)).'</pre>';
    echo '</div>';
}

function giftaccess_admin_json($data){
    $json = wp_json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

    return is_string($json) ? $json : '';
}
