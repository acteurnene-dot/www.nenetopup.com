<?php
/*
Plugin Name: Gift Access PIN
Description: Livraison digitale Gift Access pour WooCommerce.
Version: 1.3.19
Author: Gift Access
Requires at least: 6.9
Tested up to: 7.0
Requires PHP: 7.4
Requires Plugins: woocommerce
WC requires at least: 8.2
WC tested up to: 10.8.1
Text Domain: gift-access
Domain Path: /languages
*/

defined('ABSPATH') || exit;


define('GIFTACCESS_VERSION', '1.3.19');
define('GIFTACCESS_FILE', __FILE__);
define('GIFTACCESS_PATH', plugin_dir_path(__FILE__));
define('GIFTACCESS_URL', plugin_dir_url(__FILE__));
define('GIFTACCESS_ADMIN_SLUG', 'giftaccess');

add_action('before_woocommerce_init', function () {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            __FILE__,
            true
        );
    }
});

add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=' . GIFTACCESS_ADMIN_SLUG)) . '">' . esc_html__('Réglages', 'gift-access') . '</a>';
    array_unshift($links, $settings_link);

    return $links;
});

require_once GIFTACCESS_PATH . 'includes/install.php';
require_once GIFTACCESS_PATH . 'core/gift-access-core.php';


register_activation_hook(__FILE__, 'giftaccess_install');
