<?php
defined('ABSPATH') || exit;


function giftaccess_redeem_shortcode($atts = []){
    $atts = shortcode_atts([
        'url' => 'https://redeem.hype.games/widget/',
        'height' => 650,
        'class' => '',
    ], $atts, 'giftaccess_redeem');

    $url = esc_url($atts['url']);
    $height = max(300, absint($atts['height']));
    $class = sanitize_html_class((string) $atts['class']);

    ob_start(); ?>
    <div class="giftaccess-widget-box<?php echo $class ? ' '.esc_attr($class) : ''; ?>">
        <iframe
            src="<?php echo esc_url($url); ?>"
            width="100%"
            height="<?php echo esc_attr($height); ?>"
            frameborder="0"
            allowfullscreen
            loading="lazy"></iframe>
    </div>
    <style>
        .giftaccess-widget-box<?php echo $class ? '.'.esc_html($class) : ''; ?>{max-width:980px;margin:20px auto;background:#fff;border-radius:14px;border:1px solid #eee;padding:10px}
    </style>
    <?php
    return ob_get_clean();
}

add_shortcode('giftaccess_redeem', 'giftaccess_redeem_shortcode');
add_shortcode('gift_access_redeem', 'giftaccess_redeem_shortcode');
add_shortcode('giftaccess_widget', 'giftaccess_redeem_shortcode');
