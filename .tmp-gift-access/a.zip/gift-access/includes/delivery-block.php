<?php
defined('ABSPATH') || exit;

if (!defined('GIFTACCESS_REDEEM_SLUG')) {
    define('GIFTACCESS_REDEEM_SLUG', 'redeem');
}


function giftaccess_render_user_pins($order_id, $args = []){
    if (!class_exists('WooCommerce')) return;

    $order = wc_get_order($order_id);
    if (!$order) return;

    $user_id = get_current_user_id();
    if (!$user_id || (int)$order->get_user_id() !== (int)$user_id) {
        return;
    }

    global $wpdb;
    $rows = $wpdb->get_results(
        $wpdb->prepare("SELECT * FROM {$wpdb->prefix}giftaccess_stock WHERE assigned_order=%d ORDER BY id ASC", (int)$order_id),
        ARRAY_A
    );

    $api_rows = [];
    foreach ($order->get_items('line_item') as $item_id => $item) {
        $api_status = (string) $item->get_meta('_giftaccess_api_status', true);
        if ($api_status === '') {
            continue;
        }

        $api_deliveries = $item->get_meta('_giftaccess_api_deliveries', true);
        if (!is_array($api_deliveries)) {
            $api_deliveries = [];
        }

        if (empty($api_deliveries) && function_exists('giftaccess_api_normalized_deliveries')) {
            $api_response = $item->get_meta('_giftaccess_api_response', true);
            $api_deliveries = giftaccess_api_normalized_deliveries($api_response);
        }

        $api_reference = (string) $item->get_meta('_giftaccess_api_reference', true);
        if (empty($api_deliveries) && $api_status === 'success' && $api_reference !== '' && function_exists('giftaccess_api_request') && function_exists('giftaccess_api_normalized_deliveries')) {
            $details = giftaccess_api_request('GET', '/orders/' . rawurlencode($api_reference));
            if (!is_wp_error($details)) {
                $api_deliveries = giftaccess_api_normalized_deliveries($details);
                if (!empty($api_deliveries)) {
                    $item->update_meta_data('_giftaccess_api_deliveries', $api_deliveries);
                    $item->save();
                }
            }
        }

        $api_rows[] = [
            'item_id'   => (int) $item_id,
            'name'      => $item->get_name(),
            'status'    => $api_status,
            'reference' => $api_reference,
            'date'      => (string) $item->get_meta('_giftaccess_api_date', true),
            'deliveries' => $api_deliveries,
            'claimed_at' => (string) $item->get_meta('_giftaccess_api_claimed_at', true),
        ];
    }

    if (empty($rows) && empty($api_rows)) return;

    $load_assets = !isset($args['assets']) || (bool) $args['assets'];
    $has_pending_api_delivery = false;
    foreach ($api_rows as $api_row) {
        if (empty($api_row['deliveries']) && in_array($api_row['status'], ['processing', 'success'], true)) {
            $has_pending_api_delivery = true;
            break;
        }
    }

    static $did_assets = false;
    if ($load_assets && !$did_assets){
        $did_assets = true;
        add_action('wp_footer', function(){
            $delivery_block_color = function_exists('giftaccess_delivery_block_color') ? giftaccess_delivery_block_color() : '#ffffff';
            $delivery_button_color = function_exists('giftaccess_delivery_button_color') ? giftaccess_delivery_button_color() : '#d39a3c';
            ?>
<style>
.giftaccess-pins-wrap{margin-top:22px}
.giftaccess-pin-row{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:14px;padding:12px;border:1px solid #e6e6e6;border-radius:12px;flex-wrap:wrap;background:<?php echo esc_html($delivery_block_color); ?> !important}
.giftaccess-pin-left{min-width:220px}
.giftaccess-pin-title{font-weight:700;margin-bottom:6px}
.giftaccess-pin-code{font-family:monospace;font-size:15px;word-break:break-all;display:inline-block}
.giftaccess-pin-actions{display:flex;gap:10px}
.giftaccess-btn{padding:10px 16px;border-radius:10px;background:<?php echo esc_html($delivery_button_color); ?> !important;color:#fff !important;text-decoration:none;border:none;cursor:pointer;font-weight:700;display:inline-block}
.giftaccess-btn:hover{opacity:.92}
.giftaccess-btn.disabled{background:#aaa;cursor:not-allowed}
.giftaccess-toast{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);background:#111;color:#fff;padding:10px 14px;border-radius:10px;opacity:0;pointer-events:none;transition:.25s}
.giftaccess-toast.show{opacity:1}
.giftaccess-delivery-pending{opacity:.82}
@media (max-width:600px){
  .giftaccess-pin-row{flex-direction:column;align-items:flex-start}
  .giftaccess-pin-actions{width:100%;flex-direction:column}
  .giftaccess-btn{width:100%;text-align:center}
  .giftaccess-pin-left{min-width:0;width:100%}
}
</style>
<div class="giftaccess-toast" id="giftaccessToast">Copié ✅</div>
<script>
(function(){
  function toast(){
    var t=document.getElementById('giftaccessToast'); if(!t) return;
    t.classList.add('show');
    setTimeout(function(){t.classList.remove('show')}, 1100);
  }
  document.addEventListener('click', function(e){
    var btn=e.target.closest('[data-giftaccess-copy]'); if(!btn) return;
    var pin=btn.getAttribute('data-giftaccess-copy')||'';
    if(!pin) return;
    if(navigator.clipboard && navigator.clipboard.writeText){
      navigator.clipboard.writeText(pin).then(toast).catch(function(){});
    }
  });

  function scheduleRefresh(wrap){
    if(!wrap || wrap.getAttribute('data-giftaccess-pending') !== '1') return;

    var orderId = wrap.getAttribute('data-giftaccess-order') || '';
    var nonce = wrap.getAttribute('data-giftaccess-nonce') || '';
    if(!orderId || !nonce) return;

    var attempts = parseInt(wrap.getAttribute('data-giftaccess-attempts') || '0', 10);
    if(attempts >= 24) return;

    setTimeout(function(){
      var current = document.querySelector('.giftaccess-pins-wrap[data-giftaccess-order="'+orderId+'"]');
      if(!current || current.getAttribute('data-giftaccess-pending') !== '1') return;

      var body = new FormData();
      body.append('action', 'giftaccess_refresh_order_delivery');
      body.append('order_id', orderId);
      body.append('nonce', nonce);

      fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
        method: 'POST',
        credentials: 'same-origin',
        body: body
      }).then(function(response){
        return response.json();
      }).then(function(payload){
        if(!payload || !payload.success || !payload.data || !payload.data.html) return;

        var holder = document.createElement('div');
        holder.innerHTML = payload.data.html.trim();
        var next = holder.firstElementChild;
        if(!next) return;

        next.setAttribute('data-giftaccess-attempts', String(attempts + 1));
        current.replaceWith(next);
        scheduleRefresh(next);
      }).catch(function(){
        current.setAttribute('data-giftaccess-attempts', String(attempts + 1));
        scheduleRefresh(current);
      });
    }, 5000);
  }

  function bootRefresh(){
    document.querySelectorAll('.giftaccess-pins-wrap[data-giftaccess-pending="1"]').forEach(scheduleRefresh);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bootRefresh);
  } else {
    bootRefresh();
  }
})();
</script>
            <?php
        });
    }

    $delivery_block_color = function_exists('giftaccess_delivery_block_color') ? giftaccess_delivery_block_color() : '#ffffff';
    $delivery_button_color = function_exists('giftaccess_delivery_button_color') ? giftaccess_delivery_button_color() : '#d39a3c';
    $pin_block_style = 'background:' . $delivery_block_color . ' !important;';
    $pin_button_style = 'background:' . $delivery_button_color . ' !important;color:#fff !important;';

    echo '<div class="giftaccess-pins-wrap" data-giftaccess-order="'.esc_attr((string)$order_id).'" data-giftaccess-nonce="'.esc_attr(wp_create_nonce('giftaccess_refresh_order_'.$order_id)).'" data-giftaccess-pending="'.esc_attr($has_pending_api_delivery ? '1' : '0').'">';

    foreach($rows as $r){
        $pid = (int)$r['product_id'];
        $vid = !empty($r['variation_id']) ? (int)$r['variation_id'] : 0;

        $label = 'PIN';
        $p = wc_get_product($pid);
        if ($p) $label = $p->get_name();
        if ($vid){
            $v = wc_get_product($vid);
            if ($v) $label .= ' – ' . wc_get_formatted_variation($v, true, false, true);
        }

        $claim_url = function_exists('giftaccess_redeem_url') ? giftaccess_redeem_url() : site_url('/'.GIFTACCESS_REDEEM_SLUG.'/');

        echo '<div class="giftaccess-pin-row" style="'.esc_attr($pin_block_style).'">';
        echo '<div class="giftaccess-pin-left">';
        echo '<div class="giftaccess-pin-title">'.esc_html($label).'</div>';
        echo '<span class="giftaccess-pin-code">'.esc_html($r['data_pin']).'</span>';
        echo '</div>';

        echo '<div class="giftaccess-pin-actions">';
        echo '<button type="button" class="giftaccess-btn" style="'.esc_attr($pin_button_style).'" data-giftaccess-copy="'.esc_attr($r['data_pin']).'">COPIER</button>';

        echo '<a class="giftaccess-btn" style="'.esc_attr($pin_button_style).'" href="'.esc_url($claim_url).'">Réclamer</a>';

        echo '</div></div>';
    }

    foreach($api_rows as $api_row){
        if (!empty($api_row['deliveries'])) {
            $status_label = __('Livrée', 'gift-access');
        } elseif ($api_row['status'] === 'failed') {
            $status_label = __('Livraison échouée', 'gift-access');
        } else {
            $status_label = __('Livraison en cours', 'gift-access');
        }

        if (!empty($api_row['deliveries'])) {
            foreach ($api_row['deliveries'] as $delivery_index => $delivery) {
                if (!is_array($delivery) || empty($delivery['value'])) {
                    continue;
                }

                $claim_url = function_exists('giftaccess_redeem_url') ? giftaccess_redeem_url() : site_url('/'.GIFTACCESS_REDEEM_SLUG.'/');

                echo '<div class="giftaccess-pin-row" style="'.esc_attr($pin_block_style).'">';
                echo '<div class="giftaccess-pin-left">';
                echo '<div class="giftaccess-pin-title">'.esc_html($api_row['name']).'</div>';
                echo '<span class="giftaccess-pin-code">'.nl2br(esc_html($delivery['value'])).'</span>';
                echo '</div>';

                echo '<div class="giftaccess-pin-actions">';
                echo '<button type="button" class="giftaccess-btn" style="'.esc_attr($pin_button_style).'" data-giftaccess-copy="'.esc_attr($delivery['value']).'">COPIER</button>';

                echo '<a class="giftaccess-btn" style="'.esc_attr($pin_button_style).'" href="'.esc_url($claim_url).'">Réclamer</a>';

                echo '</div></div>';
            }
            continue;
        }

        echo '<div class="giftaccess-pin-row" style="'.esc_attr($pin_block_style).'">';
        echo '<div class="giftaccess-pin-left">';
        echo '<div class="giftaccess-pin-title">'.esc_html($api_row['name']).'</div>';
        echo '<span class="giftaccess-pin-code giftaccess-delivery-pending">'.esc_html($status_label).'</span>';
        echo '</div>';
        echo '<div class="giftaccess-pin-actions"></div></div>';
    }

    echo '</div>';
}

add_action('wp_ajax_giftaccess_refresh_order_delivery', function(){
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'not_logged_in'], 401);
    }

    $order_id = absint($_POST['order_id'] ?? 0);
    if (!$order_id) {
        wp_send_json_error(['message' => 'missing_order'], 400);
    }

    $nonce = sanitize_text_field(wp_unslash($_POST['nonce'] ?? ''));
    if (!wp_verify_nonce($nonce, 'giftaccess_refresh_order_'.$order_id)) {
        wp_send_json_error(['message' => 'invalid_nonce'], 403);
    }

    $order = wc_get_order($order_id);
    if (!$order || (int)$order->get_user_id() !== (int)get_current_user_id()) {
        wp_send_json_error(['message' => 'not_allowed'], 403);
    }

    if (function_exists('giftaccess_auto_deliver_order')) {
        giftaccess_auto_deliver_order($order_id);
    }

    ob_start();
    giftaccess_render_user_pins($order_id, ['assets' => false]);
    $html = trim((string) ob_get_clean());

    wp_send_json_success(['html' => $html]);
});

add_action('init', function(){
    if (!empty($_GET['giftaccess_api_claim']) && !empty($_GET['order'])) {
        if (!is_user_logged_in()) return;

        $item_id = absint($_GET['giftaccess_api_claim']);
        $order_id = absint($_GET['order']);
        $nonce = sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? ''));

        if (!$item_id || !$order_id) return;
        if (!wp_verify_nonce($nonce, 'giftaccess_api_claim_'.$item_id.'_'.$order_id)) return;

        $order = wc_get_order($order_id);
        if (!$order) return;

        if ((int)$order->get_user_id() !== (int)get_current_user_id()) return;

        $item = $order->get_item($item_id);
        if (!$item) return;

        $item->update_meta_data('_giftaccess_api_claimed_at', current_time('mysql'));
        $item->save();

        wp_safe_redirect(function_exists('giftaccess_redeem_url') ? giftaccess_redeem_url() : site_url('/'.GIFTACCESS_REDEEM_SLUG.'/'));
        exit;
    }

    if (empty($_GET['giftaccess_claim']) || empty($_GET['order'])) return;
    if (!is_user_logged_in()) return;

    $pin_id   = absint($_GET['giftaccess_claim']);
    $order_id = absint($_GET['order']);
    $nonce    = sanitize_text_field(wp_unslash($_GET['_wpnonce'] ?? ''));

    if (!$pin_id || !$order_id) return;
    if (!wp_verify_nonce($nonce, 'giftaccess_claim_'.$pin_id.'_'.$order_id)) return;

    $order = wc_get_order($order_id);
    if (!$order) return;

    if ((int)$order->get_user_id() !== (int)get_current_user_id()) return;

    global $wpdb;
    $t = giftaccess_stock_table();

    // Simple vérification d'existence
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT id FROM $t WHERE id=%d AND assigned_order=%d LIMIT 1",
        $pin_id, $order_id
    ));

    if (!$row) return;

    giftaccess_mark_claimed($pin_id);

    wp_safe_redirect(function_exists('giftaccess_redeem_url') ? giftaccess_redeem_url() : site_url('/'.GIFTACCESS_REDEEM_SLUG.'/'));
    exit;
});

