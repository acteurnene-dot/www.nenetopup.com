<?php
defined('ABSPATH') || exit;

function giftaccess_api_option($key, $default = ''){
    return get_option('giftaccess_api_' . $key, $default);
}

function giftaccess_api_is_enabled(){
    return 'yes' === giftaccess_api_option('enabled', 'no');
}

function giftaccess_api_mode(){
    $mode = sanitize_key((string) giftaccess_api_option('mode', 'production'));
    return in_array($mode, ['production', 'sandbox'], true) ? $mode : 'production';
}

function giftaccess_api_is_sandbox(){
    return giftaccess_api_mode() === 'sandbox';
}

function giftaccess_api_environment_option($key, $default = '', $mode = null){
    $mode = $mode === null ? giftaccess_api_mode() : sanitize_key((string) $mode);
    if (!in_array($mode, ['production', 'sandbox'], true)) {
        $mode = 'production';
    }

    return giftaccess_api_option($mode . '_' . $key, $default);
}

function giftaccess_api_default_key_matches_mode($mode){
    $default_key = trim((string) giftaccess_api_option('key', ''));
    if ($default_key === '') {
        return false;
    }

    return $mode === 'sandbox'
        ? strpos($default_key, 'ga_sbox_') === 0
        : strpos($default_key, 'ga_live_') === 0;
}

function giftaccess_api_base_url($mode = null){
    $mode = $mode === null ? giftaccess_api_mode() : sanitize_key((string) $mode);
    $url = trim((string) giftaccess_api_environment_option('base_url', '', $mode));
    if ($url === '') {
        $url = trim((string) giftaccess_api_option('base_url', ''));
    }

    if ($url === '') {
        $url = 'https://portal.gift-access.com/api/v1';
    }

    return rtrim(esc_url_raw($url), '/');
}

function giftaccess_api_key($mode = null){
    $mode = $mode === null ? giftaccess_api_mode() : sanitize_key((string) $mode);
    $key = trim((string) giftaccess_api_environment_option('key', '', $mode));
    if ($key === '' && giftaccess_api_default_key_matches_mode($mode)) {
        $key = trim((string) giftaccess_api_option('key', ''));
    }

    return $key;
}

function giftaccess_api_secret($mode = null){
    $mode = $mode === null ? giftaccess_api_mode() : sanitize_key((string) $mode);
    $secret = trim((string) giftaccess_api_environment_option('secret', '', $mode));
    if ($secret === '' && giftaccess_api_default_key_matches_mode($mode)) {
        $secret = trim((string) giftaccess_api_option('secret', ''));
    }

    return $secret;
}

function giftaccess_api_timeout(){
    $timeout = absint(giftaccess_api_option('timeout', 30));
    return max(5, min(120, $timeout));
}

function giftaccess_api_logs_option(){
    return 'giftaccess_api_logs';
}

function giftaccess_api_log($level, $message, $context = []){
    $logs = get_option(giftaccess_api_logs_option(), []);
    if (!is_array($logs)) {
        $logs = [];
    }

    $logs[] = [
        'time'    => gmdate('Y-m-d H:i:s'),
        'level'   => sanitize_text_field($level),
        'message' => sanitize_text_field($message),
        'context' => giftaccess_api_sanitize_context($context),
    ];

    if (count($logs) > 500) {
        $logs = array_slice($logs, -500);
    }

    update_option(giftaccess_api_logs_option(), $logs, false);

    if (function_exists('wc_get_logger')) {
        $logger = wc_get_logger();
        $method = method_exists($logger, $level) ? $level : 'info';
        $logger->{$method}($message, ['source' => 'gift-access-api', 'context' => end($logs)]);
    }
}

function giftaccess_api_sanitize_context($value){
    if (is_array($value)) {
        $out = [];
        foreach ($value as $key => $child) {
            $safe_key = sanitize_key((string) $key);
            if (in_array($safe_key, ['x_api_signature', 'x_api_key', 'secret', 'client_secret', 'authorization', 'password', 'cvv'], true)) {
                $out[$safe_key] = '***';
                continue;
            }
            $out[$safe_key] = giftaccess_api_sanitize_context($child);
        }
        return $out;
    }

    if (is_object($value)) {
        return giftaccess_api_sanitize_context((array) $value);
    }

    if (is_bool($value) || is_numeric($value)) {
        return $value;
    }

    return sanitize_text_field((string) $value);
}

function giftaccess_api_get_logs($limit = 200){
    $logs = get_option(giftaccess_api_logs_option(), []);
    if (!is_array($logs)) {
        return [];
    }

    $logs = array_reverse($logs);
    $limit = absint($limit);

    return $limit > 0 ? array_slice($logs, 0, $limit) : $logs;
}

function giftaccess_api_get_logs_with_ids($limit = 200){
    $logs = get_option(giftaccess_api_logs_option(), []);
    if (!is_array($logs)) {
        return [];
    }

    $logs = array_reverse($logs, true);
    $limit = absint($limit);
    $out = [];

    foreach ($logs as $log_id => $log) {
        if (!is_array($log)) {
            continue;
        }

        $log['_log_id'] = (int) $log_id;
        $out[] = $log;

        if ($limit > 0 && count($out) >= $limit) {
            break;
        }
    }

    return $out;
}

function giftaccess_api_get_log($log_id){
    $logs = get_option(giftaccess_api_logs_option(), []);
    if (!is_array($logs)) {
        return null;
    }

    $log_id = absint($log_id);

    return isset($logs[$log_id]) && is_array($logs[$log_id]) ? $logs[$log_id] : null;
}

function giftaccess_api_clear_logs(){
    update_option(giftaccess_api_logs_option(), [], false);
}

function giftaccess_api_signature($method, $endpoint, $body, $timestamp){
    $base_path = (string) parse_url(giftaccess_api_base_url(), PHP_URL_PATH);
    $path = '/' . trim($base_path, '/') . '/' . ltrim((string) $endpoint, '/');
    $path = preg_replace('#/+#', '/', $path);
    $payload = $timestamp . strtoupper((string) $method) . $path . $body;

    return hash_hmac('sha256', $payload, giftaccess_api_secret());
}

function giftaccess_api_timestamp(){
    $now = time();
    $last = (int) get_option('giftaccess_api_last_timestamp', 0);
    $timestamp = max($now, $last + 1);

    if ($timestamp > ($now + 240)) {
        $timestamp = $now;
    }

    update_option('giftaccess_api_last_timestamp', $timestamp, false);

    return (string) $timestamp;
}

function giftaccess_api_expected_key_prefix($mode = null){
    $mode = $mode === null ? giftaccess_api_mode() : sanitize_key((string) $mode);
    return $mode === 'sandbox' ? 'ga_sbox_' : 'ga_live_';
}

function giftaccess_api_key_hint($mode = null){
    $key = giftaccess_api_key($mode);
    if ($key === '') {
        return '';
    }

    return substr($key, 0, 8) . '...' . substr($key, -4);
}

function giftaccess_api_active_context($extra = []){
    return array_merge([
        'mode' => giftaccess_api_mode(),
        'base_url' => giftaccess_api_base_url(),
        'key_prefix' => giftaccess_api_expected_key_prefix(),
        'key_hint' => giftaccess_api_key_hint(),
    ], is_array($extra) ? $extra : []);
}

function giftaccess_api_validate_active_credentials(){
    $mode = giftaccess_api_mode();
    $key = giftaccess_api_key($mode);
    $secret = giftaccess_api_secret($mode);

    if ($key === '' || $secret === '') {
        return new WP_Error(
            'missing_api_credentials',
            $mode === 'sandbox'
                ? __('Ajoutez la clé API sandbox et le secret sandbox avant de tester ou livrer.', 'gift-access')
                : __('Ajoutez la clé API production et le secret production avant de tester ou livrer.', 'gift-access')
        );
    }

    $expected_prefix = giftaccess_api_expected_key_prefix($mode);
    if (strpos($key, $expected_prefix) !== 0) {
        return new WP_Error(
            'api_environment_mismatch',
            sprintf(
                /* translators: 1: current mode, 2: expected key prefix */
                __('La clé API active ne correspond pas au mode %1$s. Utilisez une clé qui commence par %2$s.', 'gift-access'),
                $mode,
                $expected_prefix
            )
        );
    }

    return true;
}

function giftaccess_api_request($method, $endpoint, $payload = [], $extra_headers = []){
    $credentials_check = giftaccess_api_validate_active_credentials();
    if (is_wp_error($credentials_check)) {
        giftaccess_api_log('error', 'Configuration API Gift Access invalide.', [
            'endpoint' => $endpoint,
            'mode' => giftaccess_api_mode(),
            'message' => $credentials_check->get_error_message(),
        ]);

        return $credentials_check;
    }

    $method = strtoupper((string) $method);
    $endpoint = '/' . ltrim((string) $endpoint, '/');
    $body = '';

    if (!empty($payload)) {
        $body = wp_json_encode($payload, JSON_UNESCAPED_SLASHES);
    }

    $timestamp = giftaccess_api_timestamp();
    $headers = array_merge([
        'Accept'          => 'application/json',
        'Content-Type'    => 'application/json',
        'X-API-KEY'       => giftaccess_api_key(),
        'X-API-TIMESTAMP' => $timestamp,
        'X-API-SIGNATURE' => giftaccess_api_signature($method, $endpoint, $body, $timestamp),
    ], $extra_headers);

    $args = [
        'method'  => $method,
        'timeout' => giftaccess_api_timeout(),
        'headers' => $headers,
    ];

    if ($body !== '') {
        $args['body'] = $body;
    }

    $url = giftaccess_api_base_url() . $endpoint;
    $response = wp_remote_request($url, $args);

    if (is_wp_error($response)) {
        giftaccess_api_log('error', 'Erreur transport API Gift Access.', giftaccess_api_active_context([
            'endpoint' => $endpoint,
            'method' => $method,
            'timestamp' => $timestamp,
            'idempotency_key_present' => isset($headers['Idempotency-Key']),
            'payload'  => $payload,
            'error'    => $response->get_error_message(),
        ]));
        return $response;
    }

    $status = absint(wp_remote_retrieve_response_code($response));
    $raw = (string) wp_remote_retrieve_body($response);
    $decoded = json_decode($raw, true);
    $body_for_log = is_array($decoded) ? $decoded : $raw;

    if ($status < 200 || $status >= 300 || (is_array($decoded) && isset($decoded['success']) && false === (bool) $decoded['success'])) {
        $message = giftaccess_api_error_message($decoded, wp_remote_retrieve_response_message($response));
        giftaccess_api_log('error', 'Requête API Gift Access échouée.', giftaccess_api_active_context([
            'endpoint' => $endpoint,
            'method' => $method,
            'status'   => $status,
            'message'  => $message,
            'timestamp' => $timestamp,
            'idempotency_key_present' => isset($headers['Idempotency-Key']),
            'payload'  => $payload,
            'response' => $body_for_log,
        ]));

        return new WP_Error('giftaccess_api_error', $message, [
            'status' => $status,
            'body'   => $body_for_log,
        ]);
    }

    giftaccess_api_log('info', 'Requête API Gift Access réussie.', giftaccess_api_active_context([
        'endpoint' => $endpoint,
        'method' => $method,
        'status'   => $status,
        'timestamp' => $timestamp,
        'idempotency_key_present' => isset($headers['Idempotency-Key']),
        'payload'  => $payload,
        'response' => $body_for_log,
    ]));

    return is_array($decoded) ? $decoded : ['raw' => $raw];
}

function giftaccess_api_error_message($decoded, $fallback = ''){
    if (is_array($decoded)) {
        if (!empty($decoded['error']['message'])) {
            return (string) $decoded['error']['message'];
        }
        if (!empty($decoded['message'])) {
            return (string) $decoded['message'];
        }
        if (!empty($decoded['error']) && is_string($decoded['error'])) {
            return $decoded['error'];
        }
    }

    return $fallback ? (string) $fallback : __('La requête API Gift Access a échoué.', 'gift-access');
}

function giftaccess_api_test_connection(){
    $ping = giftaccess_api_request('GET', '/ping');
    if (is_wp_error($ping)) {
        return $ping;
    }

    $environment_check = giftaccess_api_validate_remote_environment($ping);
    if (is_wp_error($environment_check)) {
        return $environment_check;
    }

    $balance = giftaccess_api_request('GET', '/wallet/balance');
    if (is_wp_error($balance)) {
        return $balance;
    }

    return [
        'ping'    => $ping,
        'balance' => $balance,
    ];
}

function giftaccess_api_validate_remote_environment($ping){
    $expected_environment = giftaccess_api_mode();
    $actual_environment = isset($ping['environment']) ? sanitize_key((string) $ping['environment']) : '';

    if ($actual_environment !== '' && $actual_environment !== $expected_environment) {
        return new WP_Error(
            'api_environment_mismatch',
            sprintf(
                /* translators: 1: expected API environment, 2: actual API environment */
                __('Le mode du plugin est %1$s, mais la clé API répond en %2$s.', 'gift-access'),
                $expected_environment,
                $actual_environment
            )
        );
    }

    return true;
}

function giftaccess_api_assert_remote_environment(){
    $ping = giftaccess_api_request('GET', '/ping');
    if (is_wp_error($ping)) {
        return $ping;
    }

    return giftaccess_api_validate_remote_environment($ping);
}

function giftaccess_api_create_order($payload){
    $idempotency_key = '';
    if (isset($payload['idempotency_key'])) {
        $idempotency_key = (string) $payload['idempotency_key'];
        unset($payload['idempotency_key']);
    }

    if ($idempotency_key === '' && !empty($payload['reference'])) {
        $idempotency_key = (string) $payload['reference'];
    }

    if ($idempotency_key === '' && function_exists('wp_generate_uuid4')) {
        $idempotency_key = wp_generate_uuid4();
    }

    $environment_check = giftaccess_api_assert_remote_environment();
    if (is_wp_error($environment_check)) {
        return $environment_check;
    }

    return giftaccess_api_request('POST', '/orders', $payload, [
        'Idempotency-Key' => $idempotency_key,
    ]);
}

function giftaccess_meta_with_parent_fallback($product, $meta_key, $default = '', $fallback_on_empty = true){
    $product_obj = is_a($product, 'WC_Product') ? $product : wc_get_product($product);
    if (!$product_obj) {
        return $default;
    }

    $product_id = $product_obj->get_id();
    if (metadata_exists('post', $product_id, $meta_key)) {
        $value = get_post_meta($product_id, $meta_key, true);
        if ($value !== 'inherit') {
            $has_value = true;
            if ($fallback_on_empty) {
                $has_value = !(is_scalar($value) && trim((string) $value) === '');
            }

            if ($has_value || (string) $value === '0') {
                return $value;
            }
        }
    }

    $parent_id = $product_obj->get_parent_id();
    if ($parent_id && metadata_exists('post', $parent_id, $meta_key)) {
        return get_post_meta($parent_id, $meta_key, true);
    }

    return $default;
}

function giftaccess_api_product_mapping($product){
    $service = sanitize_key((string) giftaccess_meta_with_parent_fallback($product, '_giftaccess_api_service_type', 'freefire'));
    if (!in_array($service, ['freefire', 'giftcard', 'airtime', 'topup'], true)) {
        $service = 'freefire';
    }

    $delivery_mode = sanitize_key((string) giftaccess_meta_with_parent_fallback($product, '_giftaccess_delivery_mode', 'stock', false));
    if (!in_array($delivery_mode, ['stock', 'api', 'hybrid'], true)) {
        $delivery_mode = 'stock';
    }

    $enabled = sanitize_key((string) giftaccess_meta_with_parent_fallback($product, '_giftaccess_api_enabled', 'no', false));
    if (!in_array($enabled, ['yes', 'no'], true)) {
        $enabled = 'no';
    }

    return [
        'enabled'        => $enabled,
        'delivery_mode'  => $delivery_mode,
        'service_type'   => $service,
        'product_id'     => sanitize_text_field((string) giftaccess_meta_with_parent_fallback($product, '_giftaccess_api_product_id', '')),
        'variation_ref'  => sanitize_text_field((string) giftaccess_meta_with_parent_fallback($product, '_giftaccess_api_variation_ref', '')),
        'fixed_amount'   => (float) giftaccess_meta_with_parent_fallback($product, '_giftaccess_api_fixed_amount', ''),
        'currency'       => strtoupper(sanitize_text_field((string) giftaccess_meta_with_parent_fallback($product, '_giftaccess_api_currency', 'USD'))),
        'country'        => strtoupper(sanitize_text_field((string) giftaccess_meta_with_parent_fallback($product, '_giftaccess_api_country', ''))),
        'operator_brand' => sanitize_text_field((string) giftaccess_meta_with_parent_fallback($product, '_giftaccess_api_operator_brand', '')),
    ];
}

function giftaccess_api_product_is_enabled($product){
    $mapping = giftaccess_api_product_mapping($product);
    return giftaccess_api_is_enabled()
        && $mapping['enabled'] === 'yes'
        && in_array($mapping['delivery_mode'], ['api', 'hybrid'], true)
        && trim((string) $mapping['product_id']) !== '';
}

function giftaccess_api_build_order_payload($order, $item, $mapping, $quantity){
    $product_id = trim((string) $mapping['product_id']);
    if ($product_id === '') {
        return new WP_Error('missing_api_product_id', __('ID produit API manquant.', 'gift-access'));
    }

    $quantity = max(1, min(100, absint($quantity)));
    $reference = sprintf('giftaccess-%d-%d', $order->get_id(), $item->get_id());
    $fields = [
        'recipient_name'  => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
        'recipient_email' => sanitize_email($order->get_billing_email()),
        'woo_order_id'    => (string) $order->get_id(),
        'woo_item_id'     => (string) $item->get_id(),
        'service_type'    => $mapping['service_type'],
    ];

    if ($fields['recipient_name'] === '') {
        $fields['recipient_name'] = __('Customer', 'gift-access');
    }

    foreach ($item->get_meta_data() as $meta_data) {
        $key = isset($meta_data->key) ? (string) $meta_data->key : '';
        if ($key === '' || substr($key, 0, 1) === '_') {
            continue;
        }

        $value = isset($meta_data->value) ? $meta_data->value : '';
        if (is_array($value) || is_object($value)) {
            continue;
        }

        $value = wc_clean((string) $value);
        if (trim($value) === '') {
            continue;
        }

        $fields[$key] = $value;
    }

    $account_id = trim((string) $item->get_meta('_giftaccess_account_id', true));
    if ($account_id === '') {
        foreach (['account_id', 'player_id', 'uid', 'UID', 'User ID', 'ID joueur', 'Id joueur', 'id joueur'] as $candidate_key) {
            $candidate = trim((string) $item->get_meta($candidate_key, true));
            if ($candidate !== '') {
                $account_id = $candidate;
                break;
            }
        }
    }

    if ($account_id !== '') {
        $account_id = wc_clean($account_id);
        $fields['account_id'] = $account_id;
        if (empty($fields['player_id'])) {
            $fields['player_id'] = $account_id;
        }
    }

    $payload = [
        'product_id' => $product_id,
        'quantity'   => $quantity,
        'reference'  => $reference,
        'fields'     => $fields,
    ];

    $variation_ref = trim((string) $mapping['variation_ref']);
    if ($variation_ref !== '' && $variation_ref !== $product_id) {
        $payload['variation_ref'] = sanitize_text_field($variation_ref);
    }

    $payload['idempotency_key'] = giftaccess_api_idempotency_key($reference, $payload);

    return $payload;
}

function giftaccess_api_idempotency_key($reference, $payload){
    $normalized = giftaccess_api_normalize_payload($payload);
    $encoded = wp_json_encode($normalized, JSON_UNESCAPED_SLASHES);
    if (!is_string($encoded) || $encoded === '') {
        $encoded = serialize($normalized);
    }

    return sanitize_key($reference . '-' . substr(hash('sha256', $encoded), 0, 12));
}

function giftaccess_api_normalize_payload($value){
    if (!is_array($value)) {
        return $value;
    }

    $is_list = array_keys($value) === range(0, count($value) - 1);
    if (!$is_list) {
        ksort($value);
    }

    foreach ($value as $key => $child) {
        $value[$key] = giftaccess_api_normalize_payload($child);
    }

    return $value;
}

function giftaccess_api_extract_reference($response, $payload = []){
    if (is_string($response) && trim($response) !== '') {
        return sanitize_text_field(trim($response, "\" \t\n\r\0\x0B"));
    }

    if (is_array($response)) {
        foreach (['order_id', 'order_number', 'id', 'requestId', 'transactionId', 'transaction_id', 'referenceId', 'reference'] as $key) {
            if (!empty($response[$key])) {
                return sanitize_text_field((string) $response[$key]);
            }
        }

        if (!empty($response['data']) && is_array($response['data'])) {
            return giftaccess_api_extract_reference($response['data'], $payload);
        }
    }

    return !empty($payload['reference']) ? sanitize_text_field((string) $payload['reference']) : '';
}

function giftaccess_api_delivery_items_from_response($response){
    if (!is_array($response)) {
        return [];
    }

    if (!empty($response['delivery']['items']) && is_array($response['delivery']['items'])) {
        return $response['delivery']['items'];
    }

    if (!empty($response['order']['delivery']['items']) && is_array($response['order']['delivery']['items'])) {
        return $response['order']['delivery']['items'];
    }

    if (!empty($response['data']) && is_array($response['data'])) {
        return giftaccess_api_delivery_items_from_response($response['data']);
    }

    return [];
}

function giftaccess_api_enrich_order_response($response, $payload = []){
    if (!is_array($response) || !empty(giftaccess_api_delivery_items_from_response($response))) {
        return $response;
    }

    $order_id = '';
    foreach (['order_id', 'order_number', 'id'] as $key) {
        if (!empty($response[$key])) {
            $order_id = (string) $response[$key];
            break;
        }
    }

    if ($order_id === '' && !empty($payload['reference'])) {
        $order_id = (string) $payload['reference'];
    }

    if ($order_id === '') {
        return $response;
    }

    $details = giftaccess_api_request('GET', '/orders/' . rawurlencode($order_id));
    if (is_wp_error($details) || !is_array($details)) {
        return $response;
    }

    if (!empty($details['order']) && is_array($details['order'])) {
        foreach (['delivery', 'billing', 'product', 'requested_amount', 'face_value'] as $key) {
            if (!isset($response[$key]) && isset($details['order'][$key])) {
                $response[$key] = $details['order'][$key];
            }
        }
    }

    return $response;
}

function giftaccess_api_normalized_deliveries($response){
    $deliveries = [];

    foreach (giftaccess_api_delivery_items_from_response($response) as $item) {
        if (!is_array($item)) {
            continue;
        }

        $type = sanitize_key((string) ($item['type'] ?? 'pin'));
        $label = 'PIN';
        $value = '';

        if ($type === 'email_pass') {
            $email = trim((string) ($item['login_email'] ?? ''));
            $password = trim((string) ($item['login_password'] ?? ''));
            $label = __('Compte', 'gift-access');
            $value = trim($email . ($password !== '' ? "\n" . $password : ''));
        } elseif ($type === 'code') {
            $label = __('Code', 'gift-access');
            foreach (['code', 'pin', 'pin_code'] as $key) {
                if (!empty($item[$key])) {
                    $value = (string) $item[$key];
                    break;
                }
            }
        } else {
            $type = 'pin';
            $value = (string) ($item['pin_code'] ?? $item['pin'] ?? $item['code'] ?? '');
        }

        $value = trim($value);
        if ($value === '') {
            continue;
        }

        $deliveries[] = [
            'type' => $type,
            'label' => sanitize_text_field($label),
            'value' => sanitize_textarea_field($value),
        ];
    }

    return $deliveries;
}

function giftaccess_api_item_deliveries($item){
    if (!$item) {
        return [];
    }

    $deliveries = $item->get_meta('_giftaccess_api_deliveries', true);
    if (!is_array($deliveries)) {
        $deliveries = [];
    }

    if (empty($deliveries)) {
        $response = $item->get_meta('_giftaccess_api_response', true);
        $deliveries = giftaccess_api_normalized_deliveries($response);
    }

    return array_values(array_filter($deliveries, function($delivery){
        return is_array($delivery) && trim((string)($delivery['value'] ?? '')) !== '';
    }));
}

function giftaccess_api_refresh_item_deliveries($order, $item_id, $item, $minimum_quantity = 1, $force = false){
    $existing = giftaccess_api_item_deliveries($item);
    if (count($existing) >= max(1, (int) $minimum_quantity)) {
        return true;
    }

    $reference = (string) $item->get_meta('_giftaccess_api_reference', true);
    if ($reference === '') {
        return new WP_Error('missing_api_reference', __('Référence API manquante pour vérifier la livraison.', 'gift-access'));
    }

    $last_refresh = strtotime((string) $item->get_meta('_giftaccess_api_last_refresh', true));
    if (!$force && $last_refresh && (time() - $last_refresh) < 8) {
        return new WP_Error('api_delivery_pending', __('Livraison API en cours. Nouvelle vérification dans quelques secondes.', 'gift-access'));
    }

    $item->update_meta_data('_giftaccess_api_last_refresh', gmdate('Y-m-d H:i:s'));
    $item->save();

    $details = giftaccess_api_request('GET', '/orders/' . rawurlencode($reference));
    if (is_wp_error($details)) {
        $item->update_meta_data('_giftaccess_api_last_error', $details->get_error_message());
        $item->save();

        return $details;
    }

    $deliveries = giftaccess_api_normalized_deliveries($details);
    $remote_status = sanitize_key((string) ($details['status'] ?? ($details['order']['status'] ?? '')));

    $item->update_meta_data('_giftaccess_api_response', $details);

    if (!empty($deliveries)) {
        $item->update_meta_data('_giftaccess_api_status', 'success');
        $item->update_meta_data('_giftaccess_api_deliveries', $deliveries);
        $item->update_meta_data('_giftaccess_api_quantity', max(count($deliveries), max(1, (int) $minimum_quantity)));
        $item->update_meta_data('_giftaccess_api_last_error', '');
        $item->save();

        if ($order && method_exists($order, 'add_order_note')) {
            $order->add_order_note(sprintf(
                __('Livraison API récupérée pour "%1$s"%2$s.', 'gift-access'),
                $item->get_name(),
                $reference ? ' (référence : ' . $reference . ')' : ''
            ));
        }

        return true;
    }

    if (in_array($remote_status, ['failed', 'failure', 'error', 'cancelled', 'canceled'], true)) {
        $item->update_meta_data('_giftaccess_api_status', 'failed');
        $item->update_meta_data('_giftaccess_api_last_error', __('La commande API a échoué chez le fournisseur.', 'gift-access'));
        $item->update_meta_data('_giftaccess_api_quantity', 0);
        $item->save();

        return new WP_Error('api_delivery_failed', __('La commande API a échoué chez le fournisseur.', 'gift-access'));
    }

    $item->update_meta_data('_giftaccess_api_status', 'processing');
    $item->update_meta_data('_giftaccess_api_quantity', 0);
    $item->update_meta_data('_giftaccess_api_last_error', __('Aucun code de livraison disponible pour le moment.', 'gift-access'));
    $item->save();
    $order->update_meta_data('_giftaccess_api_pending', 'yes');
    $order->save();

    return new WP_Error('api_delivery_pending', __('Livraison API en cours. Les codes ne sont pas encore disponibles.', 'gift-access'));
}

function giftaccess_api_deliver_item($order, $item_id, $item, $quantity){
    if (!giftaccess_api_is_enabled()) {
        return new WP_Error('api_disabled', __('API désactivée dans les réglages.', 'gift-access'));
    }

    $status = (string) $item->get_meta('_giftaccess_api_status', true);
    $existing_deliveries = giftaccess_api_item_deliveries($item);
    if ($status === 'success' && count($existing_deliveries) >= max(1, (int) $quantity)) {
        return true;
    }

    $existing_reference = (string) $item->get_meta('_giftaccess_api_reference', true);
    if ($existing_reference !== '' && in_array($status, ['processing', 'success'], true)) {
        return giftaccess_api_refresh_item_deliveries($order, $item_id, $item, $quantity);
    }

    if ($status === 'processing') {
        $last_attempt = strtotime((string) $item->get_meta('_giftaccess_api_last_attempt', true));
        if ($last_attempt && (time() - $last_attempt) < 45) {
            return new WP_Error(
                'api_delivery_in_progress',
                __('Livraison API deja en cours pour cet article. Nouvelle tentative ignoree quelques secondes.', 'gift-access')
            );
        }
    }

    $product = $item->get_product();
    if (!$product) {
        return new WP_Error('missing_product', __('Produit WooCommerce introuvable.', 'gift-access'));
    }

    $mapping = giftaccess_api_product_mapping($product);
    if ($mapping['enabled'] !== 'yes' || !in_array($mapping['delivery_mode'], ['api', 'hybrid'], true)) {
        return new WP_Error('api_not_enabled_for_product', __('API non activée pour ce produit.', 'gift-access'));
    }

    $payload = giftaccess_api_build_order_payload($order, $item, $mapping, $quantity);
    if (is_wp_error($payload)) {
        return $payload;
    }

    $item->update_meta_data('_giftaccess_api_status', 'processing');
    $item->update_meta_data('_giftaccess_api_last_attempt', gmdate('Y-m-d H:i:s'));
    $item->update_meta_data('_giftaccess_api_payload', $payload);
    $item->save();

    $response = giftaccess_api_create_order($payload);
    if (is_wp_error($response)) {
        $item->update_meta_data('_giftaccess_api_status', 'failed');
        $item->update_meta_data('_giftaccess_api_last_error', $response->get_error_message());
        $item->update_meta_data('_giftaccess_api_error_data', $response->get_error_data());
        $item->save();

        $order->add_order_note(sprintf(
            __('Livraison API échouée pour "%1$s" : %2$s', 'gift-access'),
            $item->get_name(),
            $response->get_error_message()
        ));

        return $response;
    }

    $response = giftaccess_api_enrich_order_response($response, $payload);
    $reference = giftaccess_api_extract_reference($response, $payload);
    $deliveries = giftaccess_api_normalized_deliveries($response);
    $item->update_meta_data('_giftaccess_api_reference', $reference);
    $item->update_meta_data('_giftaccess_api_response', $response);
    $item->update_meta_data('_giftaccess_api_date', gmdate('Y-m-d H:i:s'));
    if (!empty($deliveries)) {
        $item->update_meta_data('_giftaccess_api_status', 'success');
        $item->update_meta_data('_giftaccess_api_deliveries', $deliveries);
        $item->update_meta_data('_giftaccess_api_quantity', max(count($deliveries), max(1, absint($quantity))));
        $item->update_meta_data('_giftaccess_api_last_error', '');
        $item->save();

        $order->add_order_note(sprintf(
            __('Livraison API réussie pour "%1$s"%2$s.', 'gift-access'),
            $item->get_name(),
            $reference ? ' (référence : ' . $reference . ')' : ''
        ));

        return true;
    }

    $item->update_meta_data('_giftaccess_api_status', 'processing');
    $item->update_meta_data('_giftaccess_api_quantity', 0);
    $item->update_meta_data('_giftaccess_api_last_error', __('Aucun code de livraison disponible pour le moment.', 'gift-access'));
    $item->save();
    $order->update_meta_data('_giftaccess_api_pending', 'yes');
    $order->save();

    $order->add_order_note(sprintf(
        __('Commande API créée pour "%1$s"%2$s, livraison en attente.', 'gift-access'),
        $item->get_name(),
        $reference ? ' (référence : ' . $reference . ')' : ''
    ));

    return new WP_Error('api_delivery_pending', __('Commande API créée, mais les codes ne sont pas encore disponibles.', 'gift-access'));
}
