<?php
defined('ABSPATH') || exit;

if (!defined('GIFTACCESS_REDEEM_SLUG')) {
    define('GIFTACCESS_REDEEM_SLUG', 'redeem');
}

function giftaccess_stock_table(){ global $wpdb; return $wpdb->prefix . 'giftaccess_stock'; }
function giftaccess_history_table(){ global $wpdb; return $wpdb->prefix . 'giftaccess_history'; }

function giftaccess_setting($key, $default = ''){
    return get_option('giftaccess_' . $key, $default);
}

function giftaccess_sanitize_hex_setting($value, $default){
    $color = sanitize_hex_color((string) $value);
    return $color ? $color : $default;
}

function giftaccess_delivery_block_color(){
    return giftaccess_sanitize_hex_setting(giftaccess_setting('delivery_block_color', '#ffffff'), '#ffffff');
}

function giftaccess_delivery_button_color(){
    return giftaccess_sanitize_hex_setting(giftaccess_setting('delivery_button_color', '#d39a3c'), '#d39a3c');
}

function giftaccess_redeem_url(){
    $url = trim((string) giftaccess_setting('redeem_url', ''));
    if ($url === '') {
        $url = site_url('/' . GIFTACCESS_REDEEM_SLUG . '/');
    }

    return esc_url_raw($url);
}

function giftaccess_product_has_pins($product_id, $variation_id = null){
    global $wpdb; $t = giftaccess_stock_table();

    if ($variation_id) {
        return (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $t WHERE product_id=%d AND (variation_id=%d OR variation_id IS NULL) LIMIT 1",
            (int) $product_id,
            (int) $variation_id
        ));
    }

    return (bool) $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $t WHERE product_id=%d LIMIT 1",
        (int) $product_id
    ));
}

function giftaccess_count_free($product_id, $variation_id = null){
    global $wpdb; $t = giftaccess_stock_table();
    if ($variation_id){
        return (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $t WHERE product_id=%d AND variation_id=%d AND assigned_order IS NULL",
            $product_id, $variation_id
        ));
    }
    return (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $t WHERE product_id=%d AND variation_id IS NULL AND assigned_order IS NULL",
        $product_id
    ));
}

function giftaccess_get_free_pin($product_id, $variation_id = null){
    global $wpdb; $t = giftaccess_stock_table();
    if ($variation_id){
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $t WHERE product_id=%d AND variation_id=%d AND assigned_order IS NULL ORDER BY id ASC LIMIT 1",
            $product_id, $variation_id
        ), ARRAY_A);
        if ($row) {
            return $row;
        }

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $t WHERE product_id=%d AND variation_id IS NULL AND assigned_order IS NULL ORDER BY id ASC LIMIT 1",
            $product_id
        ), ARRAY_A);
    }
    return $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $t WHERE product_id=%d AND variation_id IS NULL AND assigned_order IS NULL ORDER BY id ASC LIMIT 1",
        $product_id
    ), ARRAY_A);
}

function giftaccess_mark_assigned($row_id, $order_id, $item_id){
    global $wpdb; $t = giftaccess_stock_table();
    $wpdb->update($t, [
        'assigned_order' => (int)$order_id,
        'assigned_item'  => (int)$item_id,
        'assigned_at'    => current_time('mysql'),
    ], ['id' => (int)$row_id], ['%d','%d','%s'], ['%d']);
}

function giftaccess_history_log($row, $order_id, $item_id){
    if (!$row) return;
    global $wpdb; $t = giftaccess_history_table();
    $wpdb->insert($t, [
        'product_id'   => (int)$row['product_id'],
        'variation_id' => !empty($row['variation_id']) ? (int)$row['variation_id'] : null,
        'order_id'     => (int)$order_id,
        'item_id'      => (int)$item_id,
        'data_pin'     => (string)$row['data_pin'],
    ], ['%d','%d','%d','%d','%s']);
}

function giftaccess_mark_claimed($row_id){
    global $wpdb; $t = giftaccess_stock_table();
    $wpdb->update($t, ['claimed_at' => current_time('mysql')], ['id' => (int)$row_id], ['%s'], ['%d']);
}

function giftaccess_insert_pin($product_id, $variation_id, $pin){
    global $wpdb; $t = giftaccess_stock_table();

    $pin = trim((string)$pin);
    if ($pin === '') return false;

    $exists = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $t
         WHERE product_id=%d
           AND COALESCE(variation_id,0)=COALESCE(%d,0)
           AND data_pin=%s
           AND assigned_order IS NULL
         LIMIT 1",
        (int)$product_id, (int)($variation_id ?: 0), $pin
    ));
    if ($exists) return false;

    $ok = $wpdb->insert($t, [
        'product_id'     => (int)$product_id,
        'variation_id'   => $variation_id ? (int)$variation_id : null,
        'data_pin'       => $pin,
        'assigned_order' => null,
        'assigned_item'  => null,
        'assigned_at'    => null,
        'claimed_at'     => null,
    ]);

    if (!$ok) return false;

    
    giftaccess_sync_stock((int)$product_id, $variation_id ? (int)$variation_id : null);

    
    giftaccess_process_processing_orders();

    return true;
}


function giftaccess_delete_pin($row_id){
    global $wpdb; $t = giftaccess_stock_table();

    
    $row = $wpdb->get_row(
        $wpdb->prepare("SELECT product_id, variation_id, assigned_order FROM $t WHERE id=%d", (int)$row_id),
        ARRAY_A
    );
    if (!$row) return;

   
    if (!empty($row['assigned_order'])) return;

    $wpdb->delete($t, ['id' => (int)$row_id]);

    giftaccess_sync_stock(
        (int)$row['product_id'],
        !empty($row['variation_id']) ? (int)$row['variation_id'] : null
    );
}


function giftaccess_get_variations($product_id){
    $p = wc_get_product($product_id);
    if (!$p || !$p->is_type('variable')) return [];
    $out=[];
    foreach($p->get_children() as $vid){
        $v = wc_get_product($vid);
        if (!$v) continue;
        $out[] = ['id'=>$vid, 'label'=>wc_get_formatted_variation($v, true, false, true)];
    }
    return $out;
}

function giftaccess_import_csv($product_id, $variation_id, $tmp){
    if (!file_exists($tmp)) return 0;
    $fh = fopen($tmp,'r'); if(!$fh) return 0;
    $headers = fgetcsv($fh, 0, ','); if(!$headers){ fclose($fh); return 0; }
    $lc = array_map(function($v){ return strtolower(trim($v)); }, $headers);
    $idx = array_search('pin', $lc);
    if ($idx === false) $idx = array_search('codepin', $lc);
    if ($idx === false) $idx = 0;

    $count=0;
    while(($row=fgetcsv($fh,0,','))!==false){
        if (!isset($row[$idx])) continue;
        $pin = sanitize_text_field($row[$idx]);
        if ($pin==='') continue;
        if (giftaccess_insert_pin($product_id, $variation_id, $pin)) $count++;
    }
    fclose($fh);
    giftaccess_sync_stock($product_id, $variation_id ?: null);
    return $count;
}

function giftaccess_order_has_pending_api_delivery($order){
    if (!$order || !method_exists($order, 'get_items')) {
        return false;
    }

    foreach ($order->get_items() as $item) {
        $status = (string) $item->get_meta('_giftaccess_api_status', true);
        $reference = (string) $item->get_meta('_giftaccess_api_reference', true);
        if ($reference === '' || !in_array($status, ['processing', 'success'], true)) {
            continue;
        }

        $deliveries = function_exists('giftaccess_api_item_deliveries')
            ? giftaccess_api_item_deliveries($item)
            : [];

        if (empty($deliveries)) {
            return true;
        }
    }

    return false;
}

function giftaccess_auto_deliver_order($order_id){
    if (!class_exists('WooCommerce')) return;

    $order = wc_get_order($order_id);
    if (!$order) return;

    
    if ($order->get_meta('_giftaccess_done') === 'yes' && !giftaccess_order_has_pending_api_delivery($order)) return;

    $all_assigned = true;
    $delivered_anything = false;
    $managed_items = 0;

    foreach ($order->get_items() as $item_id => $item){

        $pid = (int) $item->get_product_id();
        $vid = (int) $item->get_variation_id();
        $vid = $vid ?: null;

        $product = $item->get_product();
        if (!$product) {
            continue;
        }

        $has_stock = giftaccess_product_has_pins($pid, $vid);
        $api_enabled = function_exists('giftaccess_api_product_is_enabled') && giftaccess_api_product_is_enabled($product);

        if (!$has_stock && !$api_enabled) {
            continue;
        }

        $managed_items++;

        $qty = max(1, (int)$item->get_quantity());

        
        $pins = wc_get_order_item_meta($item_id, '_giftaccess_pins', true);
        if (!is_array($pins)) $pins = [];

        $api_deliveries = function_exists('giftaccess_api_item_deliveries') ? giftaccess_api_item_deliveries($item) : [];
        $api_quantity_meta = (int) wc_get_order_item_meta($item_id, '_giftaccess_api_quantity', true);
        $api_delivered = !empty($api_deliveries) ? max(count($api_deliveries), max(0, $api_quantity_meta)) : 0;
        $already = count($pins) + max(0, $api_delivered);
        $need = $qty - $already;

        
        if ($need <= 0) continue;

        $mapping = $api_enabled && function_exists('giftaccess_api_product_mapping') ? giftaccess_api_product_mapping($product) : ['delivery_mode' => 'stock'];
        $delivery_mode = isset($mapping['delivery_mode']) ? $mapping['delivery_mode'] : 'stock';

        if ($delivery_mode !== 'api' && $has_stock) {
            while ($need > 0) {
                $pinrow = giftaccess_get_free_pin($pid, $vid);

                if (!$pinrow){
                    break;
                }

                giftaccess_mark_assigned((int)$pinrow['id'], $order_id, $item_id);
                giftaccess_history_log($pinrow, $order_id, $item_id);

                $pins[] = $pinrow['data_pin'];
                wc_update_order_item_meta($item_id, '_giftaccess_pins', $pins);

                $delivered_anything = true;
                $need--;
            }
        }

        if ($need > 0 && $api_enabled && in_array($delivery_mode, ['api', 'hybrid'], true)) {
            $api_result = giftaccess_api_deliver_item($order, $item_id, $item, $need);
            if (is_wp_error($api_result)) {
                $all_assigned = false;
            } else {
                $api_deliveries = function_exists('giftaccess_api_item_deliveries') ? giftaccess_api_item_deliveries($item) : [];
                $api_quantity_meta = (int) wc_get_order_item_meta($item_id, '_giftaccess_api_quantity', true);
                $api_delivered = !empty($api_deliveries) ? max(count($api_deliveries), max(0, $api_quantity_meta)) : 0;
                $need = max(0, $qty - count($pins) - $api_delivered);
                if ($need <= 0) {
                    $delivered_anything = true;
                } else {
                    $all_assigned = false;
                }
            }
        }

        if ($need > 0) {
            $all_assigned = false;
        }

        
        giftaccess_sync_stock($pid, $vid);
        if ($vid) {
            giftaccess_sync_stock($pid, null);
        }
    }

    if ($managed_items === 0) {
        return;
    }

    
    $has_pending_api = giftaccess_order_has_pending_api_delivery($order);
    if ($has_pending_api) {
        $order->update_meta_data('_giftaccess_api_pending', 'yes');
    } else {
        $order->delete_meta_data('_giftaccess_api_pending');
    }

    if ($all_assigned){
        $order->update_meta_data('_giftaccess_done', 'yes');
        $order->save();

        if ($order->has_status('completed')) {
            $order->add_order_note(__('Livraison digitale Gift Access terminée automatiquement.', 'gift-access'));
        } else {
            $order->update_status('completed', __('Livraison digitale Gift Access terminée automatiquement.', 'gift-access'));
        }
    } else {
        
        if ($delivered_anything || $has_pending_api){
            $order->save();
        }
    }
}

function giftaccess_export_stock_csv(){
    if (!current_user_can('manage_woocommerce')) wp_die('Not allowed');
    check_admin_referer('giftaccess_export_stock', 'giftaccess_export');
    global $wpdb; $t = giftaccess_stock_table();
    $rows = $wpdb->get_results("SELECT * FROM $t ORDER BY id DESC", ARRAY_A);

    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=giftaccess-stock-'.date('Ymd-His').'.csv');

    $out = fopen('php://output','w');
    fputcsv($out, ['id','product_id','variation_id','pin','assigned_order','assigned_item','assigned_at','claimed_at','created_at']);
    foreach($rows as $r){
        fputcsv($out, [$r['id'],$r['product_id'],$r['variation_id'],$r['data_pin'],$r['assigned_order'],$r['assigned_item'],$r['assigned_at'],$r['claimed_at'],$r['created_at']]);
    }
    fclose($out);
    exit;
}

function giftaccess_export_history_csv(){
    if (!current_user_can('manage_woocommerce')) wp_die('Not allowed');
    check_admin_referer('giftaccess_export_history', 'giftaccess_export');
    global $wpdb; $t = giftaccess_history_table();
    $rows = $wpdb->get_results("SELECT * FROM $t ORDER BY id DESC", ARRAY_A);

    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=giftaccess-history-'.date('Ymd-His').'.csv');

    $out = fopen('php://output','w');
    fputcsv($out, ['id','product_id','variation_id','order_id','item_id','pin','created_at']);
    foreach($rows as $r){
        fputcsv($out, [$r['id'],$r['product_id'],$r['variation_id'],$r['order_id'],$r['item_id'],$r['data_pin'],$r['created_at']]);
    }
    fclose($out);
    exit;
}

function giftaccess_product_uses_remote_delivery($product){
    if (!is_a($product, 'WC_Product') || !function_exists('giftaccess_api_product_mapping')) {
        return false;
    }

    $mapping = giftaccess_api_product_mapping($product);

    return ($mapping['enabled'] ?? 'no') === 'yes'
        && in_array($mapping['delivery_mode'] ?? 'stock', ['api', 'hybrid'], true)
        && trim((string)($mapping['product_id'] ?? '')) !== '';
}

function giftaccess_keep_wc_product_available_for_remote_delivery($product){
    if (!is_a($product, 'WC_Product')) {
        return;
    }

    if (method_exists($product, 'set_virtual')) {
        $product->set_virtual(true);
    }

    if (method_exists($product, 'set_manage_stock')) {
        $product->set_manage_stock(false);
    }

    if (method_exists($product, 'set_stock_quantity')) {
        $product->set_stock_quantity(null);
    }

    if (method_exists($product, 'set_stock_status')) {
        $product->set_stock_status('instock');
    }

    $product->save();
}

function giftaccess_sync_stock_to_wc($product_id, $variation_id = null){
    if (!class_exists('WooCommerce')) return;

    global $wpdb;
    $table = $wpdb->prefix . 'giftaccess_stock';

    $parent_product = wc_get_product($product_id);
    if ($parent_product && method_exists($parent_product, 'set_virtual')) {
        $parent_product->set_virtual(true);
        $parent_product->save();
    }

   
    if ($variation_id){
        $variation = wc_get_product($variation_id);
        if (!$variation) return;

        if (giftaccess_product_uses_remote_delivery($variation)) {
            giftaccess_keep_wc_product_available_for_remote_delivery($variation);
            if ($parent_product) {
                giftaccess_keep_wc_product_available_for_remote_delivery($parent_product);
            }

            return;
        }

        $has_any = (int)$wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $table
                 WHERE product_id=%d AND variation_id=%d",
                $product_id, $variation_id
            )
        );
        if (!$has_any) return;

        $free = (int)$wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $table
                 WHERE product_id=%d AND variation_id=%d AND assigned_order IS NULL",
                $product_id, $variation_id
            )
        );

        if (method_exists($variation, 'set_virtual')) {
            $variation->set_virtual(true);
        }
        $variation->set_manage_stock(true);
        $variation->set_stock_quantity(max(0, $free));
        $variation->set_stock_status($free > 0 ? 'instock' : 'outofstock');
        $variation->save();

        return;
    }

    
    $has_any = (int)$wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $table
             WHERE product_id=%d AND variation_id IS NULL",
            $product_id
        )
    );
    if (!$has_any) return;

    $free = (int)$wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM $table
             WHERE product_id=%d AND variation_id IS NULL AND assigned_order IS NULL",
            $product_id
        )
    );

    $product = wc_get_product($product_id);
    if (!$product) return;

    if (giftaccess_product_uses_remote_delivery($product)) {
        giftaccess_keep_wc_product_available_for_remote_delivery($product);
        return;
    }

    $product->set_manage_stock(true);
    $product->set_stock_quantity(max(0, $free));
    $product->set_stock_status($free > 0 ? 'instock' : 'outofstock');
    $product->save();
}
function giftaccess_sync_stock($product_id, $variation_id = null){
    
    if (function_exists('giftaccess_sync_stock_to_wc')) {
        giftaccess_sync_stock_to_wc((int)$product_id, $variation_id ? (int)$variation_id : null);
    }
}
function giftaccess_process_processing_orders(){
    if (!class_exists('WooCommerce')) return;

    $queries = [
        [
            'status'       => ['processing', 'completed'],
            'limit'        => 50,
            'meta_key'     => '_giftaccess_done',
            'meta_compare' => 'NOT EXISTS',
            'orderby'      => 'date',
            'order'        => 'ASC',
            'return'       => 'objects',
        ],
        [
            'status'     => ['processing', 'completed'],
            'limit'      => 50,
            'meta_key'   => '_giftaccess_api_pending',
            'meta_value' => 'yes',
            'orderby'    => 'date',
            'order'      => 'ASC',
            'return'     => 'objects',
        ],
    ];

    $seen = [];
    foreach ($queries as $query_args) {
        $orders = wc_get_orders($query_args);
        foreach ($orders as $order){
            $order_id = (int) $order->get_id();
            if (isset($seen[$order_id])) {
                continue;
            }

            $seen[$order_id] = true;
            giftaccess_auto_deliver_order($order_id);
        }
    }
}

function giftaccess_api_product_needs_account_id($product){
    if (!is_a($product, 'WC_Product') || !function_exists('giftaccess_api_product_mapping')) {
        return false;
    }

    $mapping = giftaccess_api_product_mapping($product);

    return ($mapping['enabled'] ?? 'no') === 'yes'
        && in_array($mapping['delivery_mode'] ?? 'stock', ['api', 'hybrid'], true)
        && ($mapping['service_type'] ?? '') === 'topup';
}

function giftaccess_product_needs_account_field($product){
    if (!is_a($product, 'WC_Product')) {
        return false;
    }

    if (giftaccess_api_product_needs_account_id($product)) {
        return true;
    }

    if ($product->is_type('variable')) {
        foreach ($product->get_children() as $variation_id) {
            $variation = wc_get_product($variation_id);
            if ($variation && giftaccess_api_product_needs_account_id($variation)) {
                return true;
            }
        }
    }

    return false;
}

add_action('woocommerce_before_add_to_cart_button', function(){
    global $product;

    if (!giftaccess_product_needs_account_field($product)) {
        return;
    }

    $value = isset($_POST['giftaccess_account_id'])
        ? sanitize_text_field(wp_unslash($_POST['giftaccess_account_id']))
        : '';

    echo '<div class="giftaccess-account-field" style="margin:16px 0;">';
    woocommerce_form_field('giftaccess_account_id', [
        'type'        => 'text',
        'required'    => true,
        'label'       => __('ID joueur / compte', 'gift-access'),
        'placeholder' => __('Exemple : 123456789', 'gift-access'),
        'class'       => ['form-row-wide'],
    ], $value);
    echo '</div>';
});

add_filter('woocommerce_add_to_cart_validation', function($passed, $product_id, $quantity, $variation_id = 0){
    $product = wc_get_product($variation_id ? $variation_id : $product_id);

    if (!$product || !giftaccess_api_product_needs_account_id($product)) {
        return $passed;
    }

    $account_id = isset($_POST['giftaccess_account_id'])
        ? trim((string) wp_unslash($_POST['giftaccess_account_id']))
        : '';

    if ($account_id === '') {
        wc_add_notice(__("Renseignez l'ID joueur / compte avant de continuer.", 'gift-access'), 'error');
        return false;
    }

    return $passed;
}, 10, 4);

add_filter('woocommerce_add_cart_item_data', function($cart_item_data, $product_id, $variation_id = 0){
    $product = wc_get_product($variation_id ? $variation_id : $product_id);
    if (!$product || !giftaccess_api_product_needs_account_id($product)) {
        return $cart_item_data;
    }

    $account_id = isset($_POST['giftaccess_account_id'])
        ? sanitize_text_field(wp_unslash($_POST['giftaccess_account_id']))
        : '';

    if ($account_id !== '') {
        $cart_item_data['_giftaccess_account_id'] = $account_id;
        $cart_item_data['_giftaccess_unique_key'] = md5($account_id . '|' . microtime(true));
    }

    return $cart_item_data;
}, 10, 3);

add_filter('woocommerce_get_item_data', function($item_data, $cart_item){
    if (!empty($cart_item['_giftaccess_account_id'])) {
        $item_data[] = [
            'key'   => __('ID joueur', 'gift-access'),
            'value' => wc_clean($cart_item['_giftaccess_account_id']),
        ];
    }

    return $item_data;
}, 10, 2);

add_action('woocommerce_checkout_create_order_line_item', function($item, $cart_item_key, $values, $order){
    if (empty($values['_giftaccess_account_id'])) {
        return;
    }

    $account_id = wc_clean($values['_giftaccess_account_id']);
    $item->add_meta_data('_giftaccess_account_id', $account_id, true);
    $item->add_meta_data(__('ID joueur', 'gift-access'), $account_id, true);
}, 10, 4);

add_filter('woocommerce_is_sold_individually', function($sold_individually, $product){
    if (is_admin() || !is_a($product, 'WC_Product')) return $sold_individually;

    $product_id = $product->is_type('variation') ? $product->get_parent_id() : $product->get_id();
    $variation_id = $product->is_type('variation') ? $product->get_id() : null;

    return giftaccess_product_has_pins($product_id, $variation_id) ? false : $sold_individually;

}, 10, 2);

add_action('woocommerce_email_after_order_table', function($order, $sent_to_admin, $plain_text, $email){

   
    if ($sent_to_admin) return;

    if (!is_a($order, 'WC_Order')) return;

    global $wpdb;
    $table = $wpdb->prefix . 'giftaccess_stock';

    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT * FROM $table WHERE assigned_order=%d ORDER BY id ASC",
            $order->get_id()
        ),
        ARRAY_A
    );

    $api_rows = [];
    foreach ($order->get_items('line_item') as $item) {
        $api_status = (string) $item->get_meta('_giftaccess_api_status', true);
        if ($api_status === '') {
            continue;
        }

        $api_rows[] = [
            'name'      => $item->get_name(),
            'status'    => $api_status,
            'reference' => (string) $item->get_meta('_giftaccess_api_reference', true),
            'date'      => (string) $item->get_meta('_giftaccess_api_date', true),
            'deliveries' => is_array($item->get_meta('_giftaccess_api_deliveries', true))
                ? $item->get_meta('_giftaccess_api_deliveries', true)
                : [],
        ];
    }

    if (empty($rows) && empty($api_rows)) return;

    echo '<h3 style="margin-top:15px;">Livraison digitale</h3>';
    echo '<div style="padding:12px;border:1px solid #ddd;border-radius:10px;">';

    foreach ($rows as $r){
        echo '<p style="margin:6px 0;">
            <strong>PIN :</strong>
            <code style="font-size:14px;">'.esc_html($r['data_pin']).'</code>
        </p>';
    }

    foreach ($api_rows as $api_row){
        $status_label = $api_row['status'] === 'success' ? 'Livrée' : ucfirst($api_row['status']);
        echo '<p style="margin:6px 0;">
            <strong>'.esc_html($api_row['name']).' :</strong>
            '.esc_html($status_label);
        if ($api_row['reference'] !== '') {
            echo '<br><small>Référence API : <code>'.esc_html($api_row['reference']).'</code></small>';
        }
        if ($api_row['date'] !== '') {
            echo '<br><small>Date : '.esc_html($api_row['date']).' UTC</small>';
        }
        if (!empty($api_row['deliveries'])) {
            foreach ($api_row['deliveries'] as $delivery) {
                if (is_array($delivery) && !empty($delivery['value'])) {
                    echo '<br><strong>Code :</strong> <code>'.nl2br(esc_html($delivery['value'])).'</code>';
                }
            }
        }
        echo '</p>';
    }

    if (!empty($rows)) {
        echo '<p style="margin-top:10px;">
       Copiez et Activez vos codes ici : 
        <a href="'.esc_url(giftaccess_redeem_url()).'">
            '.esc_html(giftaccess_redeem_url()).'
        </a>
    </p>';
    }

    echo '</div>';

}, 20, 4);

