<?php
defined('ABSPATH') || exit;

function giftaccess_install(){
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $stock = $wpdb->prefix . 'giftaccess_stock';
    $hist  = $wpdb->prefix . 'giftaccess_history';

    $sql1 = "CREATE TABLE IF NOT EXISTS $stock (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        product_id BIGINT UNSIGNED NOT NULL,
        variation_id BIGINT UNSIGNED NULL,
        data_pin VARCHAR(190) NOT NULL,
        assigned_order BIGINT UNSIGNED NULL,
        assigned_item BIGINT UNSIGNED NULL,
        assigned_at DATETIME NULL,
        claimed_at DATETIME NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY product_id (product_id),
        KEY variation_id (variation_id),
        KEY assigned_order (assigned_order),
        KEY claimed_at (claimed_at)
    ) $charset;";

    $sql2 = "CREATE TABLE IF NOT EXISTS $hist (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        product_id BIGINT UNSIGNED NOT NULL,
        variation_id BIGINT UNSIGNED NULL,
        order_id BIGINT UNSIGNED NOT NULL,
        item_id BIGINT UNSIGNED NOT NULL,
        data_pin VARCHAR(190) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY product_id (product_id),
        KEY order_id (order_id)
    ) $charset;";

    dbDelta($sql1);
    dbDelta($sql2);

    
    $cols = $wpdb->get_results("SHOW COLUMNS FROM $stock LIKE 'claimed_at'");
    if (empty($cols)){
        $wpdb->query("ALTER TABLE $stock ADD COLUMN claimed_at DATETIME NULL AFTER assigned_at");
    }
}
