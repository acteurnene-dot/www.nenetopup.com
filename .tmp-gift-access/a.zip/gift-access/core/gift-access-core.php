<?php
defined('ABSPATH') || exit;


require_once GIFTACCESS_PATH . 'includes/api.php';
require_once GIFTACCESS_PATH . 'includes/install.php';
require_once GIFTACCESS_PATH . 'includes/functions.php';
require_once GIFTACCESS_PATH . 'includes/delivery-block.php';
require_once GIFTACCESS_PATH . 'includes/shortcode.php';


if (is_admin()) {
    require_once GIFTACCESS_PATH . 'admin/gift-access-admin.php';
}

if (is_admin()) {
    add_action('admin_notices', function () {
        if (!class_exists('WooCommerce') && !function_exists('WC') && !function_exists('wc_get_products')) {
            echo '<div class="notice notice-error"><p><strong>Gift Access</strong> nécessite WooCommerce actif pour fonctionner.</p></div>';
        }
    });
}


add_action('woocommerce_order_status_processing', function ($order_id) {
    giftaccess_auto_deliver_order($order_id);
});

add_action('woocommerce_order_status_completed', function ($order_id) {
    giftaccess_auto_deliver_order($order_id);
});

add_action('woocommerce_payment_complete', function ($order_id) {
    giftaccess_auto_deliver_order($order_id);
});

add_action('woocommerce_thankyou', function ($order_id) {
    giftaccess_render_user_pins($order_id);
}, 15);


add_action('woocommerce_view_order', function ($order_id) {
    giftaccess_render_user_pins($order_id);
}, 20);

add_filter('cron_schedules', function ($schedules) {
    if (!isset($schedules['giftaccess_five_minutes'])) {
        $schedules['giftaccess_five_minutes'] = [
            'interval' => 5 * MINUTE_IN_SECONDS,
            'display'  => __('Toutes les 5 minutes', 'gift-access'),
        ];
    }

    return $schedules;
});

add_action('giftaccess_process_processing_orders_cron', function () {
    giftaccess_process_processing_orders();
});

add_action('init', function () {
    if (!wp_next_scheduled('giftaccess_process_processing_orders_cron')) {
        wp_schedule_event(time() + MINUTE_IN_SECONDS, 'giftaccess_five_minutes', 'giftaccess_process_processing_orders_cron');
    }
});

register_deactivation_hook(GIFTACCESS_FILE, function () {
    wp_clear_scheduled_hook('giftaccess_process_processing_orders_cron');
});
